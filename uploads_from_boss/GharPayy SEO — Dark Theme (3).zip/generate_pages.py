#!/usr/bin/env python3
"""GharPayy SEO Page Generator — 120+ pages for Bangalore PG/co-living."""

import os, json, textwrap
from pathlib import Path

OUT = Path("/home/user/workspace/gharpayy-seo-v2")
BASE_URL = "https://gharpayy.com"
WHATSAPP = "https://api.whatsapp.com/send?phone=+918307396042&text=Heyy!%20GHARPAYY,%20I%20am%20looking%20for%20a%20GOOD-%20talknow-%20ACCOMODATION%20in%20the%20AREA%20NEARBY"
BOOKING  = "https://cal.com/gharpayy.com/stay"
PHONE    = "+918307396042"
TEL      = "tel:+918307396042"
LOGO     = "https://gharpayy.com/img/logo/gharpayy_logo2.png"

# ─────────────── Attribution block (Perplexity Computer) ────────────────────
ATTRIB = """<!-- Created with Perplexity Computer: https://www.perplexity.ai/computer -->"""

# ─────────────── All 120 page definitions ───────────────────────────────────
# Schema: (filename, title, h1, meta_desc, page_type, area, extra_data)
# page_type: 'area' | 'college' | 'company' | 'rental' | 'special'

PAGES = [
# ───── BATCH 1 — Area Pages ─────
("pg-in-sarjapur.html","Best PG in Sarjapur Bangalore 2025 | GharPayy",
 "Premium PG in Sarjapur Bangalore","Find zero-brokerage fully furnished PG accommodation in Sarjapur Bangalore. GharPayy offers hotel-like PG for IT professionals near Wipro, Sarjapur Road tech hubs. Rooms from ₹7,000/month.",
 "area","Sarjapur",{"landmarks":["Wipro Campus Sarjapur – 1.5 km","RMZ Ecospace – 3 km","Carmelaram Railway Station – 2 km","Forum Mall – 5 km","Sarjapur Road ORR Junction – 1 km"],"hub":"Sarjapur Road / ORR"}),

("pg-in-brookefield.html","Best PG in Brookefield Bangalore 2025 | GharPayy",
 "Premium PG in Brookefield Bangalore","Fully furnished zero-brokerage PG in Brookefield Bangalore near ITPL, VTP Urban Life, and Kundalahalli Gate. Hotel-like rooms from ₹7,000/month.",
 "area","Brookefield",{"landmarks":["ITPL Tech Park – 1 km","VTP Urban Life – 0.8 km","Kundalahalli Gate Metro – 2 km","Forum Value Mall – 1.5 km","Brookefield Hospital – 0.5 km"],"hub":"Whitefield–ITPL Corridor"}),

("pg-in-kundalahalli.html","Best PG in Kundalahalli Bangalore 2025 | GharPayy",
 "Premium PG in Kundalahalli","Zero-brokerage PG in Kundalahalli Bangalore near ITPL, Brookefield tech corridor. Fully furnished hotel-like rooms from ₹7,000/month for IT professionals.",
 "area","Kundalahalli",{"landmarks":["Kundalahalli Gate Metro – 0.3 km","ITPL Tech Park – 1.8 km","Marathahalli Bridge – 3 km","Innovative Multiplex – 1.5 km","Phoenix Marketcity – 4 km"],"hub":"Whitefield Tech Zone"}),

("pg-in-panathur.html","Best PG in Panathur Bangalore 2025 | GharPayy",
 "Premium PG in Panathur Bangalore","Fully furnished PG in Panathur Bangalore near Kalyani Tech Park, Bagmane World Technology Centre. Zero brokerage, hotel-like rooms from ₹7,000/month.",
 "area","Panathur",{"landmarks":["Kalyani Tech Park – 0.5 km","Bagmane World Tech Centre – 2 km","Panathur Lake – 0.2 km","Varthur Road Junction – 0.8 km","Marathahalli – 4 km"],"hub":"Varthur–Panathur Tech Belt"}),

("pg-in-kaggadasapura.html","Best PG in Kaggadasapura Bangalore 2025 | GharPayy",
 "Premium PG in Kaggadasapura","Zero-brokerage PG in Kaggadasapura Bangalore near CV Raman Nagar, DRDO, Indira Nagar. Hotel-like furnished rooms from ₹7,000/month.",
 "area","Kaggadasapura",{"landmarks":["DRDO Campus – 1 km","CV Raman Nagar – 1.5 km","Indira Nagar 100ft Road – 3 km","New Thippasandra – 2 km","Domlur Junction – 4 km"],"hub":"East Bangalore — C.V. Raman Nagar belt"}),

("pg-in-horamavu.html","Best PG in Horamavu Bangalore 2025 | GharPayy",
 "Premium PG in Horamavu Bangalore","Fully furnished PG in Horamavu Bangalore near Kalkere Lake, Banaswadi Road. Zero brokerage hotel-like PG for professionals from ₹7,000/month.",
 "area","Horamavu",{"landmarks":["Horamavu Agara Lake – 0.4 km","Kalkere – 2 km","Banaswadi Junction – 2.5 km","Outer Ring Road – 1 km","BBMP Horamavu Park – 0.3 km"],"hub":"North-East Bangalore"}),

("pg-in-banaswadi.html","Best PG in Banaswadi Bangalore 2025 | GharPayy",
 "Premium PG in Banaswadi Bangalore","Zero-brokerage fully furnished PG in Banaswadi Bangalore. Hotel-like rooms near Banaswadi Metro, Ramamurthy Nagar. From ₹7,000/month.",
 "area","Banaswadi",{"landmarks":["Banaswadi Metro Station – 0.3 km","Ramamurthy Nagar – 1.5 km","Horamavu Road – 2 km","Manyata Tech Park – 5 km","Kalyan Nagar Junction – 2 km"],"hub":"North Bangalore — Metro Corridor"}),

("pg-in-kalyan-nagar.html","Best PG in Kalyan Nagar Bangalore 2025 | GharPayy",
 "Premium PG in Kalyan Nagar Bangalore","Fully furnished PG in Kalyan Nagar Bangalore near Manyata Tech Park, HBR Layout. Zero brokerage hotel-like accommodation from ₹7,000/month.",
 "area","Kalyan Nagar",{"landmarks":["Manyata Tech Park – 3 km","HBR Layout – 1 km","Nagawara Lake – 2 km","HRBR Layout – 1.5 km","Hennur Road – 2 km"],"hub":"North Bangalore"}),

("pg-in-kasturi-nagar.html","Best PG in Kasturi Nagar Bangalore 2025 | GharPayy",
 "Premium PG in Kasturi Nagar","Zero-brokerage PG in Kasturi Nagar Bangalore near CV Raman Nagar, Indira Nagar. Hotel-like furnished rooms for IT professionals from ₹7,000/month.",
 "area","Kasturi Nagar",{"landmarks":["CV Raman Nagar – 2 km","Banaswadi Road – 1.5 km","Indira Nagar 100ft Road – 3.5 km","Outer Ring Road – 2 km","New Thippasandra Main Road – 2 km"],"hub":"East Bangalore — CV Raman Nagar area"}),

("pg-in-cv-raman-nagar-ext.html","Best PG in CV Raman Nagar Extended Bangalore | GharPayy",
 "Premium PG in CV Raman Nagar Extended","Fully furnished PG in CV Raman Nagar Extended Bangalore near DRDO, HAL. Zero brokerage hotel-like rooms from ₹7,000/month for working professionals.",
 "area","CV Raman Nagar Extended",{"landmarks":["DRDO Madras Complex – 0.8 km","HAL Old Airport Road – 2 km","Indira Nagar Metro – 3 km","Kaggadasapura – 2.5 km","Old Madras Road – 1 km"],"hub":"East Bangalore — Old Airport Road Belt"}),

("pg-in-mahadevapura.html","Best PG in Mahadevapura Bangalore 2025 | GharPayy",
 "Premium PG in Mahadevapura Bangalore","Zero-brokerage PG in Mahadevapura Bangalore near Whitefield, RMZ Ecoworld, Bagmane. Hotel-like furnished rooms from ₹7,000/month.",
 "area","Mahadevapura",{"landmarks":["RMZ Ecoworld – 1 km","Bagmane Tech Park – 3 km","ITPL – 4 km","Mahadevapura Metro – 0.2 km","Whitefield Main Road – 2 km"],"hub":"East Bangalore — ORR–Whitefield Junction"}),

("pg-in-kr-puram-ext.html","Best PG in KR Puram Extended Bangalore | GharPayy",
 "Premium PG in KR Puram Extended","Fully furnished PG in KR Puram Extended Bangalore near Whitefield, Tin Factory. Zero brokerage hotel-like rooms from ₹7,000/month for IT professionals.",
 "area","KR Puram Extended",{"landmarks":["KR Puram Railway Station – 1 km","Tin Factory – 2 km","Whitefield Depot – 3 km","ITPL Road – 4 km","Thubarahalli Metro – 2.5 km"],"hub":"East Bangalore — Whitefield Gateway"}),

("pg-in-bannerghatta-road-ext.html","Best PG in Bannerghatta Road Extended Bangalore | GharPayy",
 "Premium PG in Bannerghatta Road Extended","Zero-brokerage PG in Bannerghatta Road Extended area, Bangalore. Near JP Nagar, BTM, Arekere. Hotel-like furnished rooms from ₹7,000/month.",
 "area","Bannerghatta Road Extended",{"landmarks":["JP Nagar 7th Phase – 2 km","Bannerghatta National Park Gate – 3 km","Arekere – 2 km","NICE Road Junction – 2 km","Dollar Colony – 2.5 km"],"hub":"South Bangalore — Bannerghatta Road"}),

("pg-in-kanakapura-road.html","Best PG in Kanakapura Road Bangalore 2025 | GharPayy",
 "Premium PG in Kanakapura Road Bangalore","Fully furnished PG on Kanakapura Road Bangalore near JP Nagar, Gottigere, Anjanapura. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "area","Kanakapura Road",{"landmarks":["JP Nagar Phase 1 – 3 km","Gottigere Metro – 1 km","Anjanapura – 2.5 km","NICE Road Junction – 1.5 km","Talaghattapura – 3 km"],"hub":"South Bangalore — Kanakapura Road Corridor"}),

("pg-in-ulsoor.html","Best PG in Ulsoor Bangalore 2025 | GharPayy",
 "Premium PG in Ulsoor Bangalore","Zero-brokerage PG in Ulsoor Bangalore near Indira Nagar, MG Road, HAL. Hotel-like furnished PG from ₹7,000/month close to the city center.",
 "area","Ulsoor",{"landmarks":["Ulsoor Lake – 0.2 km","MG Road Metro – 2 km","Indira Nagar 100ft Road – 3 km","HAL Old Airport Road – 2 km","Koramangala – 4 km"],"hub":"Central Bangalore — Lake Zone"}),

("pg-in-cambridge-layout.html","Best PG in Cambridge Layout Bangalore 2025 | GharPayy",
 "Premium PG in Cambridge Layout Bangalore","Fully furnished PG in Cambridge Layout Bangalore near Indira Nagar, ULSOOR, Richmond Road. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "area","Cambridge Layout",{"landmarks":["Cambridge Layout Main Road – 0.1 km","Indira Nagar Metro – 1.5 km","MG Road – 3 km","Ulsoor Lake – 2 km","CMH Road – 2 km"],"hub":"Central-East Bangalore"}),

("pg-in-vasanth-nagar.html","Best PG in Vasanth Nagar Bangalore 2025 | GharPayy",
 "Premium PG in Vasanth Nagar Bangalore","Zero-brokerage PG in Vasanth Nagar Bangalore near Cubbon Park, MG Road, CBD. Hotel-like furnished rooms from ₹7,000/month in the premium heart of Bangalore.",
 "area","Vasanth Nagar",{"landmarks":["Cubbon Park – 0.8 km","Vidhana Soudha – 1.5 km","MG Road Metro – 2 km","Sankey Tank – 1 km","Brigade Road – 2 km"],"hub":"Central Bangalore — CBD Zone"}),

("pg-in-sadashivanagar.html","Best PG in Sadashivanagar Bangalore 2025 | GharPayy",
 "Premium PG in Sadashivanagar Bangalore","Fully furnished PG in Sadashivanagar Bangalore near IISc, Hebbal, Rajajinagar. Zero brokerage hotel-like premium PG from ₹7,000/month.",
 "area","Sadashivanagar",{"landmarks":["IISc Campus Gate – 2 km","Hebbal Flyover – 3 km","Sankey Tank – 0.5 km","Palace Grounds – 1 km","Rajajinagar Metro – 2.5 km"],"hub":"North-Central Bangalore"}),

("pg-in-malleshwaram-ext.html","Best PG in Malleshwaram Extended Bangalore | GharPayy",
 "Premium PG in Malleshwaram Extended","Zero-brokerage PG in Malleshwaram Extended Bangalore near Rajajinagar, IISc, Yeshwanthpur. Hotel-like furnished rooms from ₹7,000/month.",
 "area","Malleshwaram Extended",{"landmarks":["IISc Campus – 2 km","Malleshwaram Metro – 1.5 km","Rajajinagar Metro – 2 km","Sampige Road – 1 km","Yeshwanthpur Junction – 2.5 km"],"hub":"North-West Bangalore"}),

("pg-in-rt-nagar-ext.html","Best PG in RT Nagar Extended Bangalore | GharPayy",
 "Premium PG in RT Nagar Extended Bangalore","Fully furnished PG in RT Nagar Extended Bangalore near Manyata Tech Park, Hebbal Lake. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "area","RT Nagar Extended",{"landmarks":["Manyata Tech Park – 3 km","Hebbal Lake – 2 km","RT Nagar Main Road – 0.3 km","Nagawara Lake – 2 km","Thanisandra Road – 1.5 km"],"hub":"North Bangalore — Manyata Periphery"}),

("pg-in-hennur.html","Best PG in Hennur Bangalore 2025 | GharPayy",
 "Premium PG in Hennur Bangalore","Zero-brokerage PG in Hennur Bangalore near Manyata Tech Park, Kalyan Nagar, Thanisandra. Hotel-like furnished rooms from ₹7,000/month.",
 "area","Hennur",{"landmarks":["Manyata Tech Park – 3 km","Hennur Bande Metro – 0.5 km","Kalyan Nagar – 2 km","Thanisandra Main Road – 1 km","Nagawara Lake – 2.5 km"],"hub":"North Bangalore"}),

("pg-in-kogilu.html","Best PG near Kogilu / Yelahanka Gate Bangalore | GharPayy",
 "Premium PG in Kogilu Yelahanka Gate","Fully furnished PG near Kogilu and Yelahanka Gate Bangalore near Manyata, Hebbal. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "area","Kogilu / Yelahanka Gate",{"landmarks":["Manyata Tech Park – 3.5 km","Yelahanka Junction – 3 km","Hebbal Flyover – 4 km","Kogilu Cross – 0.2 km","Thanisandra Road – 2 km"],"hub":"North Bangalore — Yelahanka Approach"}),

("pg-in-jakkur.html","Best PG in Jakkur Bangalore 2025 | GharPayy",
 "Premium PG in Jakkur Bangalore","Zero-brokerage PG in Jakkur Bangalore near Yelahanka, HAL Aerospace Museum. Hotel-like furnished rooms from ₹7,000/month for IT and aerospace professionals.",
 "area","Jakkur",{"landmarks":["Jakkur Aerodrome – 0.5 km","Yelahanka New Town – 2 km","Thanisandra Road – 3 km","GKVK Campus – 2 km","Allalasandra – 1.5 km"],"hub":"North Bangalore — Yelahanka Zone"}),

("pg-in-rachenahalli.html","Best PG in Rachenahalli Bangalore 2025 | GharPayy",
 "Premium PG in Rachenahalli Bangalore","Fully furnished PG in Rachenahalli Bangalore near Manyata Tech Park, Thanisandra. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "area","Rachenahalli",{"landmarks":["Manyata Tech Park – 1.5 km","Thanisandra Main Road – 0.5 km","Hebbal Lake – 3 km","Outer Ring Road – 2 km","Nagawara – 3 km"],"hub":"North Bangalore — Thanisandra Corridor"}),

("pg-in-devanahalli.html","Best PG in Devanahalli Bangalore 2025 | GharPayy",
 "Premium PG in Devanahalli Bangalore","Zero-brokerage PG in Devanahalli Bangalore near Kempegowda International Airport, KIADB Aerospace. Hotel-like furnished rooms from ₹7,000/month for airport and aerospace professionals.",
 "area","Devanahalli",{"landmarks":["KIAL Airport – 3 km","KIADB Aerospace SEZ – 2 km","Devanahalli Fort – 1 km","NH-44 Highway – 1 km","Devanahalli Bus Stand – 0.5 km"],"hub":"North Bangalore — Airport Zone"}),

("pg-in-bommanahalli.html","Best PG in Bommanahalli Bangalore 2025 | GharPayy",
 "Premium PG in Bommanahalli Bangalore","Fully furnished PG in Bommanahalli Bangalore near HSR Layout, Haralur Road, Electronic City. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "area","Bommanahalli",{"landmarks":["HSR Layout BDA Complex – 2 km","Bommanahalli Lake – 0.3 km","Haralur Road – 1 km","Electronic City Phase 2 – 4 km","Agara Lake – 2 km"],"hub":"South Bangalore — HSR Periphery"}),

("pg-in-hosa-road.html","Best PG in Hosa Road Bangalore 2025 | GharPayy",
 "Premium PG in Hosa Road Bangalore","Zero-brokerage PG on Hosa Road Bangalore near Electronic City, Chandapura. Hotel-like furnished rooms from ₹7,000/month for IT professionals.",
 "area","Hosa Road",{"landmarks":["Electronic City Phase 1 – 3 km","Chandapura Circle – 2 km","Hosa Road Metro – 0.2 km","Infosys Electronic City – 4 km","Begur – 2 km"],"hub":"South Bangalore — Electronic City Periphery"}),

("pg-in-singasandra.html","Best PG in Singasandra Bangalore 2025 | GharPayy",
 "Premium PG in Singasandra Bangalore","Fully furnished PG in Singasandra Bangalore near HSR Layout, BTM, Bommanahalli. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "area","Singasandra",{"landmarks":["HSR Layout 27th Main – 2 km","BTM Layout – 2.5 km","Bommanahalli Lake – 1.5 km","Bannerghatta Road – 3 km","Agara Lake – 3 km"],"hub":"South Bangalore"}),

("pg-in-gottigere.html","Best PG in Gottigere Bangalore 2025 | GharPayy",
 "Premium PG in Gottigere Bangalore","Zero-brokerage PG in Gottigere Bangalore near Bannerghatta Road, Kanakapura Road, NIA. Hotel-like furnished rooms from ₹7,000/month.",
 "area","Gottigere",{"landmarks":["Gottigere Metro – 0.2 km","Bannerghatta Main Road – 1 km","National Insurance Academy – 1.5 km","JP Nagar 7th Phase – 3 km","Kanakapura Road Junction – 2.5 km"],"hub":"South Bangalore — Metro Corridor"}),

("pg-in-kengeri.html","Best PG in Kengeri Bangalore 2025 | GharPayy",
 "Premium PG in Kengeri Bangalore","Fully furnished PG in Kengeri Bangalore near NICE Road, RV College, Mysore Road. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "area","Kengeri",{"landmarks":["Kengeri Metro – 0.3 km","RVCE Campus – 2 km","NICE Road Junction – 1.5 km","Kengeri Bus Terminal – 0.5 km","Mysore Road – 1 km"],"hub":"West Bangalore — Mysore Road Corridor"}),

# ───── BATCH 2 — College Pages ─────
("pg-near-iit-bangalore.html","Best PG near IIT Bangalore (IISc) 2025 | GharPayy",
 "Student PG near IIT Bangalore / IISc Campus","Premium zero-brokerage student PG near IISc (IIT Bangalore area) in Malleswaram and Sadashivanagar. Fully furnished hotel-like rooms from ₹7,000/month for researchers and students.",
 "college","IISc / IIT Bangalore",{"college_full":"Indian Institute of Science (IISc), Bangalore","college_area":"Malleshwaram / Sadashivanagar","courses":"Research programs, M.Tech, PhD, B.Sc Research in Engineering and Sciences","landmarks":["IISc Main Gate – 0.5 km","Malleshwaram Metro – 2 km","Yeshwanthpur Railway Station – 3 km","Rajajinagar Metro – 2.5 km","Sankey Tank – 1.5 km"]}),

("pg-near-bits-pilani-bangalore.html","Best PG near BITS Pilani Bangalore 2025 | GharPayy",
 "Student PG near BITS Pilani Bangalore","Zero-brokerage furnished PG near BITS Pilani Bangalore campus in Rajajinagar / Malleswaram. Hotel-like student rooms from ₹7,000/month.",
 "college","BITS Pilani Bangalore",{"college_full":"Birla Institute of Technology and Science — Bangalore Campus","college_area":"Rajajinagar / Malleswaram","courses":"B.E., M.E., M.Sc in Engineering, Technology and Sciences","landmarks":["BITS Pilani Bangalore Gate – 0.5 km","Rajajinagar Metro – 1.5 km","IISc – 2 km","Chord Road – 0.5 km","Malleshwaram Metro – 2 km"]}),

("pg-near-vtu-rvce.html","Best PG near VTU / RV College of Engineering Bangalore | GharPayy",
 "Student PG near RVCE / VTU Bangalore","Fully furnished PG near RV College of Engineering and VTU Bangalore in Kengeri and Jayanagar. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "college","VTU / RV College of Engineering",{"college_full":"RV College of Engineering (affiliated to Visvesvaraya Technological University)","college_area":"Kengeri / Mysore Road","courses":"B.E., M.Tech in all engineering disciplines","landmarks":["RVCE Main Gate – 0.5 km","Kengeri Metro – 2 km","NICE Road – 1 km","Mysore Road – 1.5 km","Vijayanagar Metro – 3 km"]}),

("pg-near-bms-college.html","Best PG near BMS College of Engineering Bangalore | GharPayy",
 "Student PG near BMS College Bangalore","Zero-brokerage PG near BMS College of Engineering Bangalore in Basavanagudi, Bull Temple Road. Hotel-like furnished rooms from ₹7,000/month.",
 "college","BMS College of Engineering",{"college_full":"BMS College of Engineering, Bull Temple Road, Basavanagudi","college_area":"Basavanagudi / Jayanagar","courses":"B.E., M.Tech, M.C.A in Engineering and Technology","landmarks":["BMSCE Main Gate – 0.3 km","Bull Temple – 0.5 km","National College Metro – 1 km","Jayanagar 4th Block – 2 km","Gandhi Bazaar – 1.5 km"]}),

("pg-near-msrit.html","Best PG near MSRIT MS Ramaiah Bangalore 2025 | GharPayy",
 "Student PG near MSRIT MS Ramaiah Bangalore","Fully furnished PG near MSRIT (MS Ramaiah Institute of Technology) Bangalore in Gokula Extension, Mathikere. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "college","MSRIT MS Ramaiah Institute of Technology",{"college_full":"MS Ramaiah Institute of Technology, MSR Nagar, Bangalore","college_area":"MSR Nagar / Mathikere","courses":"B.E., M.Tech, MBA in Engineering and Management","landmarks":["MSRIT Main Gate – 0.3 km","MS Ramaiah Hospital – 0.5 km","Yeshwanthpur Metro – 2.5 km","Peenya Metro – 3 km","Gokula Extension – 0.5 km"]}),

("pg-near-jain-university.html","Best PG near Jain University Bangalore 2025 | GharPayy",
 "Student PG near Jain University Bangalore","Zero-brokerage PG near Jain University Bangalore campuses (JC Road, Kanakapura Road, Jayanagar). Hotel-like furnished rooms from ₹7,000/month for Jain University students.",
 "college","Jain University",{"college_full":"Jain (Deemed-to-be University), Multiple Campuses, Bangalore","college_area":"JC Road / Jayanagar / Kanakapura Road","courses":"B.Com, BBA, B.Sc, B.Tech, MBA, M.Tech, Law","landmarks":["Jain University JC Road – 0.5 km","Gandhi Bazaar – 1.5 km","National College Metro – 1 km","Jayanagar 4th Block – 2 km","Kanakapura Road Campus – 8 km"]}),

("pg-near-cmr-college.html","Best PG near CMR College Bangalore 2025 | GharPayy",
 "Student PG near CMR College Bangalore","Fully furnished PG near CMR Group of Institutions (Bangalore) in Nagawara, Banaswadi, Kalyan Nagar. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "college","CMR College",{"college_full":"CMR Group of Institutions, AECS Layout, Bangalore","college_area":"AECS Layout / Nagawara / Kalyan Nagar","courses":"B.E., M.Tech, BBA, B.Com, MBA, BCA, MCA","landmarks":["CMR College Main Gate – 0.3 km","Nagawara Circle – 1.5 km","Banaswadi Road – 2 km","Manyata Tech Park – 4 km","Thanisandra Road – 3 km"]}),

("pg-near-presidency-university.html","Best PG near Presidency University Bangalore | GharPayy",
 "Student PG near Presidency University Bangalore","Zero-brokerage PG near Presidency University Bangalore in Yelahanka, Hebbal. Hotel-like furnished rooms from ₹7,000/month for Presidency University students.",
 "college","Presidency University",{"college_full":"Presidency University, Itgalpura, Rajanakunte, Bangalore","college_area":"Yelahanka / Rajanakunte","courses":"B.Tech, B.Sc, BBA, MBA, M.Tech, Law","landmarks":["Presidency University Gate – 0.5 km","Yelahanka New Town – 3 km","NH-44 Highway – 1 km","Devanahalli Road – 5 km","Hebbal – 7 km"]}),

("pg-near-reva-university.html","Best PG near REVA University Bangalore 2025 | GharPayy",
 "Student PG near REVA University Bangalore","Fully furnished PG near REVA University Bangalore in Yelahanka, Kattigenahalli. Zero brokerage hotel-like rooms from ₹7,000/month for REVA students.",
 "college","REVA University",{"college_full":"REVA University, Rukmini Knowledge Park, Kattigenahalli, Yelahanka, Bangalore","college_area":"Kattigenahalli / Yelahanka","courses":"B.Tech, M.Tech, BBA, MBA, BCA, B.Sc, Law, Design","landmarks":["REVA University Main Gate – 0.3 km","Yelahanka Junction – 3 km","Hebbal Lake – 7 km","NH-44 – 1.5 km","Kattigenahalli – 0.5 km"]}),

("pg-near-dayananda-sagar.html","Best PG near Dayananda Sagar University Bangalore | GharPayy",
 "Student PG near Dayananda Sagar University","Zero-brokerage PG near Dayananda Sagar University Bangalore in Kumaraswamy Layout, JP Nagar. Hotel-like furnished rooms from ₹7,000/month.",
 "college","Dayananda Sagar University",{"college_full":"Dayananda Sagar University, Shavige Malleshwara Hills, Kumaraswamy Layout, Bangalore","college_area":"Kumaraswamy Layout / Banashankari","courses":"B.E., M.Tech, BCA, MCA, BBA, MBA, B.Pharm","landmarks":["DSU Main Campus Gate – 0.3 km","Kumaraswamy Layout Metro – 1 km","JP Nagar Phase 1 – 2 km","Banashankari Temple – 3 km","NICE Road – 2 km"]}),

("pg-near-alliance-university.html","Best PG near Alliance University Bangalore 2025 | GharPayy",
 "Student PG near Alliance University Bangalore","Fully furnished PG near Alliance University Bangalore in Chandapura, Hosa Road, Anekal. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "college","Alliance University",{"college_full":"Alliance University, Chandapura-Anekal Main Road, Bangalore","college_area":"Chandapura / Anekal","courses":"B.Tech, MBA, BBA, B.Com, Law, B.Sc","landmarks":["Alliance University Gate – 0.5 km","Hosa Road Metro – 3 km","Electronic City Phase 2 – 4 km","Chandapura Circle – 1.5 km","Anekal – 3 km"]}),

("pg-near-manipal-bangalore.html","Best PG near Manipal University Bangalore | GharPayy",
 "Student PG near Manipal University Bangalore","Zero-brokerage PG near Manipal University Bangalore (Hebbal) in Hebbal, RT Nagar. Hotel-like furnished rooms from ₹7,000/month for Manipal Bangalore students.",
 "college","Manipal University Bangalore",{"college_full":"Manipal Academy of Higher Education — Bangalore Campus, Hebbal","college_area":"Hebbal / RT Nagar","courses":"MBA, PGDM, MCA, B.Sc, Allied Health Sciences","landmarks":["Manipal Bangalore Campus – 0.5 km","Hebbal Flyover – 1 km","Outer Ring Road – 1.5 km","Manyata Tech Park – 3 km","Hebbal Lake – 1 km"]}),

("pg-near-nift-bangalore.html","Best PG near NIFT Bangalore 2025 | GharPayy",
 "Student PG near NIFT Bangalore","Fully furnished PG near NIFT (National Institute of Fashion Technology) Bangalore in Domlur, Indiranagar. Zero brokerage hotel-like rooms from ₹7,000/month for design students.",
 "college","NIFT Bangalore",{"college_full":"National Institute of Fashion Technology (NIFT), Bangalore","college_area":"Domlur / Indiranagar","courses":"B.Des, M.Des, M.F.M in Fashion Design, Textile, Management","landmarks":["NIFT Bangalore Gate – 0.3 km","Domlur Junction – 0.5 km","Indira Nagar Metro – 2 km","Koramangala – 2.5 km","MG Road – 3.5 km"]}),

("pg-near-nid-bangalore.html","Best PG near NID Bangalore 2025 | GharPayy",
 "Student PG near NID Bangalore","Zero-brokerage PG near NID (National Institute of Design) Bangalore in Ulsoor, Indiranagar. Hotel-like furnished rooms from ₹7,000/month for design students.",
 "college","NID Bangalore",{"college_full":"National Institute of Design (NID) — Bengaluru Campus","college_area":"Ulsoor / Halasuru","courses":"B.Des, M.Des in Industrial Design, Communication Design, Textile","landmarks":["NID Bangalore Campus – 0.4 km","Halasuru Lake – 0.5 km","Indira Nagar Metro – 2 km","MG Road – 2.5 km","Koramangala – 3.5 km"]}),

("pg-near-xlri-bangalore.html","Best PG near XLRI / IFIM Business School Bangalore | GharPayy",
 "Executive PG near XLRI IFIM Business School Bangalore","Fully furnished PG near XLRI / IFIM Business School Bangalore in Electronic City, Begur Road. Zero brokerage hotel-like executive rooms from ₹7,000/month.",
 "college","XLRI / IFIM Business School",{"college_full":"IFIM Business School (XLRI Collaboration Partner), Electronics City, Bangalore","college_area":"Electronics City / Begur Road","courses":"MBA, PGDM, Executive MBA, International Business","landmarks":["IFIM Business School Gate – 0.3 km","Electronics City Phase 1 – 1 km","Hosa Road Metro – 2 km","Infosys EC Campus – 2 km","Begur Road – 1 km"]}),

("pg-near-mount-carmel-college.html","Best PG near Mount Carmel College Bangalore | GharPayy",
 "Girls PG near Mount Carmel College Bangalore","Zero-brokerage girls PG near Mount Carmel College Bangalore in Vasanth Nagar, Sadashivanagar. Hotel-like furnished rooms from ₹7,000/month for MCC students.",
 "college","Mount Carmel College",{"college_full":"Mount Carmel College (Autonomous), Palace Road, Vasanth Nagar, Bangalore","college_area":"Vasanth Nagar / Sadashivanagar","courses":"B.A., B.Sc., B.Com., BBA, BCA, MA, M.Sc.","landmarks":["Mount Carmel College Gate – 0.2 km","Palace Grounds – 0.8 km","Cubbon Park – 1.5 km","MG Road Metro – 2 km","Sankey Tank – 1.5 km"]}),

("pg-near-st-josephs-college.html","Best PG near St Joseph's College Bangalore 2025 | GharPayy",
 "Student PG near St Joseph's College Bangalore","Fully furnished PG near St Joseph's College Bangalore in Richmond Town, Shivaji Nagar. Zero brokerage hotel-like rooms from ₹7,000/month for SJC students.",
 "college","St Joseph's College",{"college_full":"St. Joseph's College of Commerce & St Joseph's University, Langford Road, Bangalore","college_area":"Langford Road / Richmond Town","courses":"B.Com, BBA, B.A., MBA, M.Sc., Law, B.Tech","landmarks":["St Joseph's Main Gate – 0.2 km","Richmond Road – 0.5 km","MG Road Metro – 1.5 km","Shivaji Nagar Bus Stand – 1 km","Cubbon Park – 1.5 km"]}),

("pg-near-bishops-college.html","Best PG near Bishop's College Bangalore 2025 | GharPayy",
 "Student PG near Bishop's College Bangalore","Zero-brokerage PG near Bishop's College and Bishop Cotton School Bangalore in Shivaji Nagar, Richmond Town. Hotel-like rooms from ₹7,000/month.",
 "college","Bishop's College",{"college_full":"The Bishop's Co-Ed School & Bishop Cotton Boys School, Bangalore","college_area":"Shivaji Nagar / Richmond Town","courses":"Pre-University (PUC), Higher Secondary Education","landmarks":["Bishop Cotton School Gate – 0.2 km","Shivaji Nagar Bus Stand – 0.5 km","MG Road – 1.5 km","Ulsoor Lake – 2 km","Richmond Road – 1 km"]}),

("pg-near-kristu-jayanti.html","Best PG near Kristu Jayanti College Bangalore | GharPayy",
 "Student PG near Kristu Jayanti College Bangalore","Fully furnished PG near Kristu Jayanti College Bangalore in Nagawara, Thanisandra. Zero brokerage hotel-like rooms from ₹7,000/month for KJC students.",
 "college","Kristu Jayanti College",{"college_full":"Kristu Jayanti College (Autonomous), Nagawara, Bangalore","college_area":"Nagawara / Thanisandra","courses":"B.A., B.Sc., B.Com., BCA, BBA, M.Sc., MBA, MCA, Law","landmarks":["Kristu Jayanti College Gate – 0.3 km","Nagawara Lake – 1 km","Manyata Tech Park – 3 km","Thanisandra Road – 1.5 km","Banaswadi Junction – 3 km"]}),

("pg-near-bangalore-medical-college.html","Best PG near Bangalore Medical College 2025 | GharPayy",
 "Medical Student PG near Bangalore Medical College","Zero-brokerage PG near Bangalore Medical College & Research Institute (BMCRI) in Chamrajpet, K.R. Market. Hotel-like furnished rooms from ₹7,000/month for medical students.",
 "college","Bangalore Medical College",{"college_full":"Bangalore Medical College and Research Institute (BMCRI), Chamrajpet, Bangalore","college_area":"Chamrajpet / K.R. Market","courses":"MBBS, MD, MS, Dental, Nursing, Allied Health Sciences","landmarks":["BMCRI Gate – 0.3 km","Victoria Hospital – 0.2 km","City Market – 0.8 km","KR Circle Metro – 1.5 km","Majestic Bus Stand – 1.5 km"]}),

("pg-near-kims-bangalore.html","Best PG near KIMS Hospital Bangalore 2025 | GharPayy",
 "PG near KIMS Hospital Bangalore","Fully furnished PG near KIMS (Kempegowda Institute of Medical Sciences) Hospital Bangalore in Banashankari, Jayanagar. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "college","KIMS Hospital Bangalore",{"college_full":"Kempegowda Institute of Medical Sciences (KIMS), BSK 2nd Stage, Bangalore","college_area":"Banashankari / Jayanagar","courses":"MBBS, MD, MS, Nursing, Paramedical, Allied Health Sciences","landmarks":["KIMS Hospital Main Gate – 0.2 km","Banashankari Temple – 1.5 km","Jayanagar 4th Block – 2.5 km","JP Nagar Phase 1 – 3 km","Kumaraswamy Layout – 3 km"]}),

("pg-near-oxford-college.html","Best PG near Oxford College of Engineering Bangalore | GharPayy",
 "Student PG near Oxford College of Engineering Bangalore","Zero-brokerage PG near Oxford College of Engineering Bangalore in Bommanahalli, Haralur Road. Hotel-like furnished rooms from ₹7,000/month for OCE students.",
 "college","Oxford College of Engineering",{"college_full":"Oxford College of Engineering, Bommanahalli, HSR Layout, Bangalore","college_area":"Bommanahalli / Haralur Road","courses":"B.E., M.Tech in CS, EC, ME, CV, EE branches","landmarks":["Oxford College Gate – 0.4 km","HSR Layout BDA Complex – 2 km","Electronic City – 4 km","Bommanahalli Lake – 0.5 km","Agara Lake – 2 km"]}),

("pg-near-vivekananda-college.html","Best PG near Vivekananda College Bangalore | GharPayy",
 "Student PG near Vivekananda College Bangalore","Fully furnished PG near Vivekananda College Bangalore in Rajajinagar, Yeshwanthpur. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "college","Vivekananda College",{"college_full":"Vivekananda College of Engineering and Technology, Puttenahalli, Bangalore","college_area":"Puttenahalli / Rajajinagar","courses":"B.E., M.Tech, MBA, MCA","landmarks":["Vivekananda College Gate – 0.3 km","Rajajinagar Metro – 2 km","Yeshwanthpur Railway Station – 2.5 km","Chord Road – 1 km","Peenya Road – 3 km"]}),

("pg-near-garden-city-university.html","Best PG near Garden City University Bangalore | GharPayy",
 "Student PG near Garden City University Bangalore","Zero-brokerage PG near Garden City University Bangalore in Old Madras Road, KR Puram. Hotel-like furnished rooms from ₹7,000/month for GCU students.",
 "college","Garden City University",{"college_full":"Garden City University, Belathur, Old Madras Road, Bangalore","college_area":"Belathur / Old Madras Road / KR Puram","courses":"B.Tech, MBA, BBA, B.Sc, B.Com, MCA, Law, Design","landmarks":["GCU Main Gate – 0.4 km","KR Puram Railway Station – 3 km","ITPL Road – 5 km","Old Madras Road – 0.5 km","Whitefield Depot – 4 km"]}),

("pg-near-east-west-college.html","Best PG near East West College of Engineering Bangalore | GharPayy",
 "Student PG near East West College of Engineering","Fully furnished PG near East West College of Engineering Bangalore in Mahalakshmi Layout, Rajajinagar. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "college","East West College of Engineering",{"college_full":"East West College of Engineering, Mahalakshmi Layout, Bangalore","college_area":"Mahalakshmi Layout / Rajajinagar","courses":"B.E., M.Tech in CS, EC, ME, CV, EE","landmarks":["East West College Gate – 0.2 km","Mahalakshmi Layout Main Road – 0.1 km","Rajajinagar Metro – 1.5 km","Chord Road – 1 km","Yeshwanthpur – 2 km"]}),

# ───── BATCH 3 — Tech Park / Company Pages ─────
("pg-near-wipro-campus-sarjapur.html","Best PG near Wipro Campus Sarjapur Bangalore | GharPayy",
 "PG near Wipro Campus Sarjapur Road Bangalore","Zero-brokerage fully furnished PG near Wipro Campus Sarjapur Road, Bangalore. Hotel-like rooms with food, WiFi from ₹7,000/month for Wipro employees.",
 "company","Wipro Campus Sarjapur",{"company_full":"Wipro Technologies — Sarjapur Road Campus, Bangalore","company_area":"Sarjapur Road / ORR","about":"Wipro Limited is a leading global IT, consulting and business process services company with its largest campus on Sarjapur Road housing over 20,000 employees.","landmarks":["Wipro Campus Gate – 0.5 km","RMZ Ecospace – 2 km","Marathahalli Bridge – 5 km","Forum Mall – 6 km","Carmelaram – 2 km"]}),

("pg-near-infosys-electronic-city.html","Best PG near Infosys Electronic City Bangalore | GharPayy",
 "PG near Infosys Electronic City Bangalore","Fully furnished PG near Infosys Electronic City campus, Bangalore. Zero brokerage hotel-like rooms from ₹7,000/month for Infosys employees.",
 "company","Infosys Electronic City",{"company_full":"Infosys Limited — Electronic City Campus, Hosur Road, Bangalore","company_area":"Electronic City Phase 1 & 2","about":"Infosys Electronic City is the company's flagship Bangalore campus, one of the largest tech campuses in India employing over 40,000 professionals across 110 acres.","landmarks":["Infosys EC Campus Gate 1 – 0.5 km","Electronic City Phase 1 – 0.3 km","Hosa Road Metro – 2 km","Wipro EC Campus – 1 km","Begur – 3 km"]}),

("pg-near-tcs-bangalore.html","Best PG near TCS Bangalore 2025 | GharPayy",
 "PG near TCS Bangalore Office","Zero-brokerage PG near TCS offices in Bangalore (Whitefield, Electronic City, Manyata). Hotel-like furnished rooms from ₹7,000/month for TCS employees.",
 "company","TCS Bangalore",{"company_full":"Tata Consultancy Services (TCS) — Bangalore Delivery Centers","company_area":"Whitefield / Electronic City / Manyata Tech Park","about":"TCS is India's largest IT company with multiple delivery centers across Bangalore in Whitefield, Electronic City, Manyata Tech Park and Hebbal employing over 50,000 professionals.","landmarks":["TCS Whitefield Campus – 1 km","ITPL Tech Park – 2 km","Mahadevapura Metro – 1.5 km","Manyata Tech Park – varies","Electronic City Phase 2 – varies"]}),

("pg-near-accenture-bangalore.html","Best PG near Accenture Bangalore 2025 | GharPayy",
 "PG near Accenture Bangalore Office","Fully furnished PG near Accenture offices Bangalore (Manyata, Whitefield, Hebbal). Zero brokerage hotel-like rooms from ₹7,000/month for Accenture employees.",
 "company","Accenture Bangalore",{"company_full":"Accenture Solutions Pvt Ltd — Manyata Tech Park & Whitefield, Bangalore","company_area":"Manyata Tech Park / Whitefield","about":"Accenture is a global professional services company employing over 3 lakh people in India. Its Bangalore offices in Manyata Tech Park and Whitefield house thousands of IT and consulting professionals.","landmarks":["Accenture Manyata Campus – 0.5 km","Manyata Tech Park – 0.2 km","Hebbal Lake – 2 km","Thanisandra Road – 1 km","Outer Ring Road – 2 km"]}),

("pg-near-ibm-bangalore.html","Best PG near IBM Bangalore 2025 | GharPayy",
 "PG near IBM Bangalore Office","Zero-brokerage PG near IBM India Bangalore office in Manyata Tech Park and Whitefield. Hotel-like furnished rooms from ₹7,000/month for IBM employees.",
 "company","IBM Bangalore",{"company_full":"IBM India Pvt Ltd — Manyata Tech Park & Whitefield, Bangalore","company_area":"Manyata Tech Park / Whitefield","about":"IBM India, one of the country's largest tech employers, has significant presence in Bangalore's Manyata Tech Park and Whitefield, employing thousands of software engineers, consultants and data scientists.","landmarks":["IBM Manyata Office – 0.3 km","Manyata Tech Park – 0.2 km","Hebbal Flyover – 2 km","Thanisandra Road – 1 km","Outer Ring Road – 2 km"]}),

("pg-near-oracle-bangalore.html","Best PG near Oracle Bangalore 2025 | GharPayy",
 "PG near Oracle Bangalore Office","Fully furnished PG near Oracle India Bangalore offices in Whitefield, ITPL area. Zero brokerage hotel-like rooms from ₹7,000/month for Oracle employees.",
 "company","Oracle Bangalore",{"company_full":"Oracle India Pvt Ltd — ITPL Tech Park, Whitefield, Bangalore","company_area":"Whitefield / ITPL","about":"Oracle India's Bangalore center in ITPL, Whitefield is one of its largest engineering hubs outside the US, with thousands of engineers working on cloud, database and enterprise software.","landmarks":["Oracle ITPL Office – 0.5 km","ITPL Tech Park – 0.3 km","Marathahalli – 3 km","Brookefield – 1.5 km","Kundalahalli Gate Metro – 2 km"]}),

("pg-near-microsoft-bangalore.html","Best PG near Microsoft Bangalore 2025 | GharPayy",
 "PG near Microsoft India Bangalore Office","Zero-brokerage PG near Microsoft India Development Center, Bangalore in Hebbal, Manyata. Hotel-like furnished rooms from ₹7,000/month for Microsoft employees.",
 "company","Microsoft Bangalore",{"company_full":"Microsoft India Development Center (MSIDC) — Hebbal, Bangalore","company_area":"Hebbal / Kirloskar Business Park","about":"Microsoft India's largest development center outside the US is based in Hebbal, Bangalore. MSIDC employs thousands of engineers, program managers and researchers working on global Microsoft products.","landmarks":["Microsoft MSIDC Gate – 0.5 km","Kirloskar Business Park – 0.3 km","Hebbal Lake – 1.5 km","Outer Ring Road – 1 km","Manyata Tech Park – 2 km"]}),

("pg-near-google-bangalore.html","Best PG near Google Bangalore 2025 | GharPayy",
 "PG near Google India Bangalore Office","Fully furnished PG near Google India Bangalore office in Bagmane Tech Park, Embassy Golf Links. Zero brokerage hotel-like rooms from ₹7,000/month for Google employees.",
 "company","Google Bangalore",{"company_full":"Google India Pvt Ltd — Bagmane Tech Park & Embassy Golf Links, Bangalore","company_area":"Bagmane Tech Park / Old Madras Road","about":"Google India's Bangalore office at Bagmane Tech Park and Embassy Golf Links is a key engineering hub employing hundreds of software engineers, product managers and researchers across Search, Maps, Android and Cloud.","landmarks":["Google Bagmane Office – 0.5 km","Bagmane Tech Park – 0.3 km","Byappanahalli Metro – 2 km","Whitefield Road – 4 km","ITPL – 6 km"]}),

("pg-near-amazon-bangalore.html","Best PG near Amazon Bangalore 2025 | GharPayy",
 "PG near Amazon India Bangalore Office","Zero-brokerage PG near Amazon India offices Bangalore in Bhannerghatta Road, RMZ Infinity. Hotel-like furnished rooms from ₹7,000/month for Amazon employees.",
 "company","Amazon Bangalore",{"company_full":"Amazon India — RMZ Infinity, Bhannerghatta Road & Manyata, Bangalore","company_area":"RMZ Infinity / Bhannerghatta Road","about":"Amazon India's largest office outside Seattle is in Bangalore. The RMZ Infinity campus and Bhannerghatta Road offices house thousands of engineers, operations and business teams working on Amazon's global platforms.","landmarks":["Amazon RMZ Infinity – 0.5 km","Domlur Junction – 1 km","Indiranagar Metro – 3 km","Koramangala – 3 km","HAL Road – 2 km"]}),

("pg-near-flipkart-bangalore.html","Best PG near Flipkart HQ Bangalore 2025 | GharPayy",
 "PG near Flipkart HQ Bangalore","Fully furnished PG near Flipkart HQ Bangalore in Bellandur, Embassy Tech Village. Zero brokerage hotel-like rooms from ₹7,000/month for Flipkart employees.",
 "company","Flipkart HQ Bangalore",{"company_full":"Flipkart Internet Pvt Ltd — Embassy Tech Village, Bellandur, Bangalore","company_area":"Embassy Tech Village / Bellandur","about":"Flipkart's headquarters at Embassy Tech Village in Bellandur is a landmark in Bangalore's startup ecosystem. As India's largest e-commerce company, Flipkart employs thousands of engineers, designers and business professionals here.","landmarks":["Flipkart HQ Gate – 0.5 km","Embassy Tech Village – 0.3 km","Bellandur Lake – 1 km","Marathahalli Bridge – 3 km","Outer Ring Road – 1 km"]}),

("pg-near-swiggy-bangalore.html","Best PG near Swiggy HQ Bangalore 2025 | GharPayy",
 "PG near Swiggy HQ Bangalore","Zero-brokerage PG near Swiggy HQ Bangalore in Koramangala, Indiranagar. Hotel-like furnished rooms from ₹7,000/month for Swiggy employees and food-tech professionals.",
 "company","Swiggy HQ Bangalore",{"company_full":"Bundl Technologies Pvt Ltd (Swiggy) — Embassy Tech Village & Koramangala, Bangalore","company_area":"Koramangala / Embassy Tech Village","about":"Swiggy, India's leading food delivery platform, has its headquarters and main tech office in Bangalore's Koramangala and Embassy Tech Village. The company employs thousands of engineers, data scientists and product managers.","landmarks":["Swiggy HQ – 0.5 km","Koramangala 5th Block – 1 km","Forum Mall Koramangala – 1.5 km","Indiranagar 100ft Road – 3 km","HSR Layout – 3 km"]}),

("pg-near-phonepe-bangalore.html","Best PG near PhonePe HQ Bangalore 2025 | GharPayy",
 "PG near PhonePe HQ Bangalore","Fully furnished PG near PhonePe HQ Bangalore in Embassy Tech Village, Bellandur. Zero brokerage hotel-like rooms from ₹7,000/month for fintech professionals.",
 "company","PhonePe HQ Bangalore",{"company_full":"PhonePe Pvt Ltd — Embassy Tech Village, Outer Ring Road, Bangalore","company_area":"Embassy Tech Village / Bellandur / ORR","about":"PhonePe, India's largest digital payments platform, has its headquarters at Embassy Tech Village on Outer Ring Road, Bangalore. The fintech unicorn employs thousands of engineers, data scientists and business professionals.","landmarks":["PhonePe HQ Gate – 0.4 km","Embassy Tech Village – 0.3 km","Bellandur Lake – 1 km","ORR – 0.5 km","Marathahalli Bridge – 3 km"]}),

("pg-near-byju-bangalore.html","Best PG near BYJU's HQ Bangalore 2025 | GharPayy",
 "PG near BYJU's HQ Bangalore","Zero-brokerage PG near BYJU's HQ Bangalore in IBC Knowledge Park, Bannerghatta Road. Hotel-like furnished rooms from ₹7,000/month for edtech professionals.",
 "company","BYJU's HQ Bangalore",{"company_full":"Think and Learn Pvt Ltd (BYJU'S) — IBC Knowledge Park, Bannerghatta Road, Bangalore","company_area":"IBC Knowledge Park / Bannerghatta Road","about":"BYJU's, the world's most valued edtech company, is headquartered at IBC Knowledge Park on Bannerghatta Road, Bangalore. The company employs thousands of educators, engineers and content creators.","landmarks":["BYJU's IBC Office – 0.4 km","IBC Knowledge Park – 0.3 km","JP Nagar Phase 2 – 2 km","Bilekahalli – 1 km","Bannerghatta Road – 0.3 km"]}),

("pg-near-zepto-bangalore.html","Best PG near Zepto Office Bangalore 2025 | GharPayy",
 "PG near Zepto Office Bangalore","Fully furnished PG near Zepto (KiranaKart) office Bangalore in Indiranagar area. Zero brokerage hotel-like rooms from ₹7,000/month for quick-commerce professionals.",
 "company","Zepto Office Bangalore",{"company_full":"KiranaKart Technologies Pvt Ltd (Zepto) — Indiranagar, Bangalore","company_area":"Indiranagar / Domlur","about":"Zepto, India's fastest growing quick-commerce startup, has its Bangalore tech office in Indiranagar. The company employs engineers, product managers, operations and business development teams.","landmarks":["Zepto Bangalore Office – 0.5 km","Indiranagar 100ft Road – 1 km","Indira Nagar Metro – 2 km","Domlur – 1.5 km","Koramangala – 3 km"]}),

("pg-near-cred-bangalore.html","Best PG near CRED Office Bangalore 2025 | GharPayy",
 "PG near CRED Office Bangalore","Zero-brokerage PG near CRED HQ Bangalore in Koramangala, Indiranagar. Hotel-like furnished rooms from ₹7,000/month for fintech startup professionals.",
 "company","CRED Office Bangalore",{"company_full":"Dreamplug Technologies Pvt Ltd (CRED) — Indiranagar & Koramangala, Bangalore","company_area":"Indiranagar / Koramangala","about":"CRED, India's premium fintech platform, has its offices in Bangalore's startup belt of Indiranagar and Koramangala. The company employs top engineers, designers and business professionals.","landmarks":["CRED Office Bangalore – 0.5 km","Indiranagar 100ft Road – 1 km","Koramangala 5th Block – 2 km","Indira Nagar Metro – 2 km","HSR Layout – 3 km"]}),

("pg-near-unacademy-bangalore.html","Best PG near Unacademy Bangalore 2025 | GharPayy",
 "PG near Unacademy Bangalore Office","Fully furnished PG near Unacademy Bangalore office in Koramangala, Indiranagar. Zero brokerage hotel-like rooms from ₹7,000/month for edtech professionals.",
 "company","Unacademy Bangalore",{"company_full":"Sorting Hat Technologies Pvt Ltd (Unacademy) — Koramangala, Bangalore","company_area":"Koramangala / HSR Layout","about":"Unacademy, India's largest edtech learning platform, has its headquarters and main offices in Bangalore's Koramangala startup hub. The company employs educators, engineers, content creators and business teams.","landmarks":["Unacademy HQ – 0.5 km","Koramangala 4th Block – 1 km","HSR Layout BDA – 3 km","Forum Mall – 2 km","Indiranagar – 4 km"]}),

("pg-near-razorpay-bangalore.html","Best PG near Razorpay HQ Bangalore 2025 | GharPayy",
 "PG near Razorpay HQ Bangalore","Zero-brokerage PG near Razorpay HQ Bangalore in SJR I-Hub, Koramangala. Hotel-like furnished rooms from ₹7,000/month for fintech professionals.",
 "company","Razorpay HQ Bangalore",{"company_full":"Razorpay Software Pvt Ltd — SJR I-Hub, Koramangala, Bangalore","company_area":"Koramangala / SJR I-Hub","about":"Razorpay, India's leading payments and business banking solution provider, is headquartered at SJR I-Hub in Koramangala, Bangalore. The fintech unicorn employs hundreds of engineers and product managers.","landmarks":["Razorpay HQ – 0.4 km","SJR I-Hub – 0.3 km","Koramangala 5th Block – 1 km","Forum Mall – 2 km","HSR Layout 27th Main – 2.5 km"]}),

("pg-near-ola-cabs-bangalore.html","Best PG near Ola Cabs HQ Bangalore 2025 | GharPayy",
 "PG near Ola Cabs HQ Bangalore","Fully furnished PG near Ola HQ Bangalore in Koramangala, Silk Board area. Zero brokerage hotel-like rooms from ₹7,000/month for mobility-tech professionals.",
 "company","Ola Cabs HQ Bangalore",{"company_full":"ANI Technologies Pvt Ltd (Ola) — Koramangala & Silk Board, Bangalore","company_area":"Koramangala / Silk Board","about":"Ola, India's largest mobility platform, is headquartered in Bangalore's Koramangala. The company employs engineers, data scientists, operations and product teams working on ride-hailing and EV technology.","landmarks":["Ola HQ Bangalore – 0.5 km","Silk Board Junction – 1.5 km","Koramangala 4th Block – 1 km","HSR Layout – 2 km","BTM Layout – 2 km"]}),

("pg-near-meesho-bangalore.html","Best PG near Meesho HQ Bangalore 2025 | GharPayy",
 "PG near Meesho HQ Bangalore","Zero-brokerage PG near Meesho HQ Bangalore in Bangalore Technology Cluster, Koramangala. Hotel-like furnished rooms from ₹7,000/month for social commerce professionals.",
 "company","Meesho HQ Bangalore",{"company_full":"Fashnear Technologies Pvt Ltd (Meesho) — Koramangala, Bangalore","company_area":"Koramangala / Indira Nagar","about":"Meesho, India's fastest-growing social commerce platform, has its headquarters in Bangalore's Koramangala tech cluster. The company employs thousands of engineers, product, growth and business professionals.","landmarks":["Meesho HQ – 0.5 km","Koramangala 8th Block – 1 km","HSR Layout – 2 km","Indiranagar – 3.5 km","Forum Mall – 2 km"]}),

("pg-near-namma-yatri-bangalore.html","Best PG near Namma Yatri / JUSPAY Bangalore | GharPayy",
 "PG near Namma Yatri JUSPAY Bangalore Office","Fully furnished PG near Namma Yatri / JUSPAY Bangalore office in Koramangala, Shanthinagar. Zero brokerage hotel-like rooms from ₹7,000/month for fintech/mobility professionals.",
 "company","Namma Yatri / JUSPAY Bangalore",{"company_full":"Juspay Technologies Pvt Ltd (Namma Yatri) — Koramangala & Shanthinagar, Bangalore","company_area":"Koramangala / Shanthinagar","about":"JUSPAY, the technology company behind Namma Yatri (Bangalore's own auto/cab booking app), operates from its offices in Koramangala and Shanthinagar. The company employs payments and mobility technology engineers.","landmarks":["JUSPAY Office – 0.5 km","Shanthinagar Bus Stand – 0.8 km","Koramangala – 2 km","MG Road – 2.5 km","Lalbagh Botanical Garden – 1.5 km"]}),

("pg-near-embassy-tech-village.html","Best PG near Embassy Tech Village Bangalore | GharPayy",
 "PG near Embassy Tech Village Bellandur Bangalore","Zero-brokerage PG near Embassy Tech Village, Bellandur, Bangalore. Hotel-like furnished rooms from ₹7,000/month for tech park professionals.",
 "company","Embassy Tech Village",{"company_full":"Embassy Tech Village — Outer Ring Road, Bellandur, Bangalore","company_area":"Bellandur / Outer Ring Road","about":"Embassy Tech Village is one of Bangalore's largest integrated business parks on ORR, housing Flipkart, PhonePe, Concentrix, Deutsche Bank and dozens of Fortune 500 companies employing over 50,000 professionals.","landmarks":["Embassy Tech Village Gate – 0.3 km","ORR Junction – 0.5 km","Bellandur Lake – 1 km","Marathahalli Bridge – 3 km","Silk Board – 4 km"]}),

("pg-near-global-tech-park.html","Best PG near Global Tech Park Whitefield Bangalore | GharPayy",
 "PG near Global Tech Park Whitefield Bangalore","Fully furnished PG near Global Tech Park Whitefield, Bangalore. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "company","Global Tech Park Whitefield",{"company_full":"Global Tech Park, ITPL Main Road, Whitefield, Bangalore","company_area":"Whitefield / ITPL Road","about":"Global Tech Park in Whitefield is a major commercial development housing offices of leading MNCs including Adobe, Philips Healthcare, and Motorola Solutions, employing thousands of IT professionals.","landmarks":["Global Tech Park Gate – 0.3 km","ITPL Main Road – 0.5 km","Whitefield Railway Station – 2 km","Brookefield – 1.5 km","Marathahalli – 5 km"]}),

("pg-near-sigma-tech-park.html","Best PG near Sigma Tech Park Bangalore | GharPayy",
 "PG near Sigma Tech Park Bangalore","Zero-brokerage PG near Sigma Tech Park Bangalore in Whitefield, ITPL area. Hotel-like furnished rooms from ₹7,000/month.",
 "company","Sigma Tech Park",{"company_full":"Sigma Tech Park, Whitefield Road, Bangalore","company_area":"Whitefield / Marathahalli","about":"Sigma Tech Park in Whitefield is a premium IT SEZ hosting companies like Capgemini, Mindtree and Symphony Teleca, employing thousands of software and IT professionals.","landmarks":["Sigma Tech Park Gate – 0.4 km","Marathahalli Bridge – 2 km","ITPL Tech Park – 3 km","Whitefield – 4 km","Outer Ring Road – 2.5 km"]}),

("pg-near-divyasree-tech-park.html","Best PG near Divyasree Tech Park Bangalore | GharPayy",
 "PG near Divyasree Tech Park Bangalore","Fully furnished PG near Divyasree Tech Park (NXT) Bangalore in Marathahalli, ORR. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "company","Divyasree Tech Park",{"company_full":"Divyasree Technopolis (NXT), Outer Ring Road, Marathahalli, Bangalore","company_area":"Marathahalli / Outer Ring Road","about":"Divyasree Technopolis NXT on ORR Marathahalli is a Grade-A IT park housing global companies like Cognizant, EY, PwC and Mphasis, employing thousands of IT and consulting professionals.","landmarks":["Divyasree NXT Gate – 0.3 km","ORR Marathahalli – 0.5 km","Marathahalli Bridge – 1.5 km","Kundalahalli Gate Metro – 3 km","Whitefield – 5 km"]}),

("pg-near-brigade-tech-park.html","Best PG near Brigade Tech Gardens Bangalore | GharPayy",
 "PG near Brigade Tech Gardens Brookefield Bangalore","Zero-brokerage PG near Brigade Tech Gardens, Brookefield, Bangalore. Hotel-like furnished rooms from ₹7,000/month.",
 "company","Brigade Tech Gardens",{"company_full":"Brigade Tech Gardens, EPIP Zone, Whitefield, Bangalore","company_area":"Brookefield / EPIP Zone","about":"Brigade Tech Gardens in Whitefield's EPIP Zone is a premium tech park housing Adobe Systems, Hexagon, and other global MNCs employing thousands of IT professionals.","landmarks":["Brigade Tech Gardens Gate – 0.3 km","EPIP Zone Main Road – 0.5 km","Brookefield – 1 km","ITPL Tech Park – 2 km","Whitefield Railway Station – 3 km"]}),

("pg-near-salarpuria-softzone.html","Best PG near Salarpuria Softzone Bangalore | GharPayy",
 "PG near Salarpuria Softzone Bangalore","Fully furnished PG near Salarpuria Softzone, Bellandur / ORR area, Bangalore. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "company","Salarpuria Softzone",{"company_full":"Salarpuria Sattva Softzone, Bellandur, Outer Ring Road, Bangalore","company_area":"Bellandur / Outer Ring Road","about":"Salarpuria Softzone on ORR Bellandur is a prominent IT park housing Concentrix, Teleperformance and several mid-size IT companies with thousands of employees.","landmarks":["Salarpuria Softzone Gate – 0.4 km","ORR Bellandur – 0.5 km","Embassy Tech Village – 1 km","Marathahalli – 4 km","Silk Board – 5 km"]}),

("pg-near-gopalan-innovation-mall.html","Best PG near Gopalan Innovation Mall Bangalore | GharPayy",
 "PG near Gopalan Innovation Mall Rajajinagar Bangalore","Zero-brokerage PG near Gopalan Innovation Mall and Gopalan Enterprises campuses Bangalore in Rajajinagar, Malleswaram. Hotel-like furnished rooms from ₹7,000/month.",
 "company","Gopalan Innovation Mall",{"company_full":"Gopalan Innovation Mall, Rajajinagar, Bangalore","company_area":"Rajajinagar / Malleswaram","about":"Gopalan Innovation Mall and Gopalan Tech Park in Rajajinagar hosts IT companies, retail and entertainment businesses, and is a major employment hub in west Bangalore.","landmarks":["Gopalan Mall Gate – 0.3 km","Rajajinagar Metro – 1 km","Chord Road – 1 km","Malleswaram Market – 2 km","IISc – 3 km"]}),

("pg-near-kalyani-tech-park.html","Best PG near Kalyani Tech Park Bangalore | GharPayy",
 "PG near Kalyani Tech Park Varthur Road Bangalore","Fully furnished PG near Kalyani Tech Park, Varthur Road, Bangalore. Zero brokerage hotel-like rooms from ₹7,000/month for tech park professionals.",
 "company","Kalyani Tech Park",{"company_full":"Kalyani Technopark, Varthur Road / Panathur, Bangalore","company_area":"Panathur / Varthur Road","about":"Kalyani Tech Park on Varthur Road houses companies like Syngene, Biocon, and several IT firms. The park is a key employment hub in east Bangalore's Panathur–Varthur tech belt.","landmarks":["Kalyani Tech Park Gate – 0.4 km","Panathur Lake – 0.5 km","Varthur Road Junction – 1 km","Marathahalli – 4 km","Whitefield – 5 km"]}),

("pg-near-manipal-centre.html","Best PG near Manipal Centre UB City Bangalore | GharPayy",
 "PG near Manipal Centre UB City Bangalore","Zero-brokerage PG near Manipal Centre and UB City, MG Road, Bangalore. Hotel-like furnished rooms from ₹7,000/month for CBD area professionals.",
 "company","Manipal Centre / UB City",{"company_full":"Manipal Centre & UB City, Vittal Mallya Road, Bangalore","company_area":"MG Road / Vittal Mallya Road","about":"Manipal Centre and UB City on Vittal Mallya Road are premium commercial complexes in Bangalore's CBD housing Goldman Sachs, Cisco, luxury brands and fine dining. This is Bangalore's most prestigious business address.","landmarks":["UB City / Manipal Centre – 0.3 km","MG Road Metro – 1 km","Cubbon Park – 1 km","Trinity Metro – 1.5 km","Vittal Mallya Road – 0.2 km"]}),

("pg-near-aecs-layout-tech.html","Best PG near AECS Layout Tech Zone Bangalore | GharPayy",
 "PG near AECS Layout Tech Zone Bangalore","Fully furnished PG near AECS Layout Tech Zone Bangalore near CMR, Manyata Tech Park periphery. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "company","AECS Layout Tech Zone",{"company_full":"AECS Layout IT & Business Zone, Nagawara, Bangalore","company_area":"AECS Layout / Nagawara / Thanisandra","about":"AECS Layout in north Bangalore is a thriving IT hub with offices of multiple tech companies and startups, close to Manyata Tech Park, Thanisandra Road and Nagawara's commercial zone.","landmarks":["AECS Layout Main Road – 0.2 km","CMR College – 0.5 km","Nagawara Circle – 1.5 km","Manyata Tech Park – 3 km","Thanisandra Road – 2 km"]}),

# ───── BATCH 4 — Rental / BHK Pages ─────
("1bhk-rental-koramangala.html","1BHK Flat for Rent in Koramangala Bangalore | GharPayy",
 "1BHK Rental in Koramangala Bangalore","Find premium 1BHK flats for rent in Koramangala Bangalore. Zero brokerage, fully furnished, near top companies and restaurants. Available from ₹18,000/month.",
 "rental","Koramangala",{"type":"1BHK","price_range":"₹18,000–₹35,000/month","landmarks":["Koramangala Forum Mall – 0.5 km","HSR Layout – 3 km","Silk Board – 2 km","BTM Layout – 2 km","Indiranagar – 4 km"]}),

("1bhk-rental-hsr-layout.html","1BHK Flat for Rent in HSR Layout Bangalore | GharPayy",
 "1BHK Rental in HSR Layout Bangalore","Premium 1BHK flats for rent in HSR Layout Bangalore. Zero brokerage, fully furnished, near Silk Board tech companies. Available from ₹16,000/month.",
 "rental","HSR Layout",{"type":"1BHK","price_range":"₹16,000–₹30,000/month","landmarks":["HSR Layout BDA Complex – 0.5 km","Silk Board Junction – 2 km","Koramangala – 3 km","Electronic City – 6 km","Agara Lake – 1.5 km"]}),

("1bhk-rental-whitefield.html","1BHK Flat for Rent in Whitefield Bangalore | GharPayy",
 "1BHK Rental in Whitefield Bangalore","Find 1BHK flats for rent in Whitefield Bangalore near ITPL, RMZ Ecospace. Zero brokerage, fully furnished. Available from ₹15,000/month.",
 "rental","Whitefield",{"type":"1BHK","price_range":"₹15,000–₹28,000/month","landmarks":["ITPL Tech Park – 1 km","Whitefield Railway Station – 1.5 km","Forum Value Mall – 2 km","Phoenix Marketcity – 5 km","Marathahalli – 6 km"]}),

("1bhk-rental-indiranagar.html","1BHK Flat for Rent in Indiranagar Bangalore | GharPayy",
 "1BHK Rental in Indiranagar Bangalore","Premium 1BHK flats for rent in Indiranagar Bangalore near 100ft Road, restaurants, metro. Zero brokerage, fully furnished. From ₹20,000/month.",
 "rental","Indiranagar",{"type":"1BHK","price_range":"₹20,000–₹40,000/month","landmarks":["Indira Nagar Metro – 0.3 km","100ft Road – 0.2 km","HAL Old Airport Road – 2 km","Koramangala – 4 km","MG Road – 3 km"]}),

("1bhk-rental-electronic-city.html","1BHK Flat for Rent in Electronic City Bangalore | GharPayy",
 "1BHK Rental in Electronic City Bangalore","Affordable 1BHK flats for rent in Electronic City Bangalore near Infosys, Wipro. Zero brokerage, fully furnished. Available from ₹12,000/month.",
 "rental","Electronic City",{"type":"1BHK","price_range":"₹12,000–₹22,000/month","landmarks":["Electronic City Phase 1 – 0.5 km","Infosys Campus – 1 km","Hosa Road Metro – 2 km","Bommasandra – 3 km","Begur – 4 km"]}),

("2bhk-rental-koramangala.html","2BHK Flat for Rent in Koramangala Bangalore | GharPayy",
 "2BHK Rental in Koramangala Bangalore","Premium 2BHK flats for rent in Koramangala Bangalore near Forum Mall, tech companies. Zero brokerage, fully furnished. Available from ₹28,000/month.",
 "rental","Koramangala",{"type":"2BHK","price_range":"₹28,000–₹55,000/month","landmarks":["Koramangala Forum Mall – 0.5 km","HSR Layout – 3 km","Silk Board – 2 km","BTM Layout – 2 km","Indiranagar – 4 km"]}),

("2bhk-rental-indiranagar.html","2BHK Flat for Rent in Indiranagar Bangalore | GharPayy",
 "2BHK Rental in Indiranagar Bangalore","Premium 2BHK flats for rent in Indiranagar Bangalore. Zero brokerage, fully furnished, near 100ft Road and metro. From ₹30,000/month.",
 "rental","Indiranagar",{"type":"2BHK","price_range":"₹30,000–₹60,000/month","landmarks":["Indira Nagar Metro – 0.3 km","100ft Road – 0.2 km","HAL Airport Road – 2 km","Koramangala – 4 km","MG Road – 3 km"]}),

("2bhk-rental-marathahalli.html","2BHK Flat for Rent in Marathahalli Bangalore | GharPayy",
 "2BHK Rental in Marathahalli Bangalore","Fully furnished 2BHK flats for rent in Marathahalli Bangalore near ORR tech companies. Zero brokerage. Available from ₹22,000/month.",
 "rental","Marathahalli",{"type":"2BHK","price_range":"₹22,000–₹42,000/month","landmarks":["Marathahalli Bridge – 0.3 km","Outer Ring Road – 0.2 km","ITPL – 4 km","Kundalahalli Gate Metro – 3 km","Domlur – 4 km"]}),

("2bhk-rental-sarjapur.html","2BHK Flat for Rent in Sarjapur Bangalore | GharPayy",
 "2BHK Rental in Sarjapur Road Bangalore","Fully furnished 2BHK flats for rent in Sarjapur Road Bangalore near Wipro, Infosys. Zero brokerage. Available from ₹20,000/month.",
 "rental","Sarjapur",{"type":"2BHK","price_range":"₹20,000–₹40,000/month","landmarks":["Wipro Campus – 2 km","RMZ Ecospace – 3 km","Sarjapur Road ORR – 1 km","Carmelaram – 2 km","Forum Mall – 6 km"]}),

("2bhk-rental-jp-nagar.html","2BHK Flat for Rent in JP Nagar Bangalore | GharPayy",
 "2BHK Rental in JP Nagar Bangalore","Premium 2BHK flats for rent in JP Nagar Bangalore near IBC Knowledge Park, Bannerghatta Road. Zero brokerage. From ₹22,000/month.",
 "rental","JP Nagar",{"type":"2BHK","price_range":"₹22,000–₹45,000/month","landmarks":["JP Nagar Phase 1 Arch – 0.5 km","IBC Knowledge Park – 2 km","Bannerghatta Road – 1 km","Jayanagar – 3 km","Lalbagh Garden – 4 km"]}),

("flat-rental-koramangala.html","Flat for Rent in Koramangala Bangalore | GharPayy",
 "Flat Rental in Koramangala Bangalore","Find premium fully furnished flats for rent in Koramangala Bangalore. Zero brokerage, near Forum Mall and tech companies. 1BHK from ₹18k, 2BHK from ₹28k.",
 "rental","Koramangala",{"type":"Flat","price_range":"1BHK: ₹18k–₹35k | 2BHK: ₹28k–₹55k","landmarks":["Forum Mall – 0.5 km","Silk Board – 2 km","HSR Layout – 3 km","Indiranagar – 4 km","Agara Lake – 2 km"]}),

("flat-rental-whitefield.html","Flat for Rent in Whitefield Bangalore | GharPayy",
 "Flat Rental in Whitefield Bangalore","Fully furnished flats for rent in Whitefield Bangalore near ITPL, Marathahalli. Zero brokerage. 1BHK from ₹15k, 2BHK from ₹22k.",
 "rental","Whitefield",{"type":"Flat","price_range":"1BHK: ₹15k–₹28k | 2BHK: ₹22k–₹42k","landmarks":["ITPL Tech Park – 1 km","Whitefield Railway – 1.5 km","Forum Value Mall – 2 km","Phoenix Marketcity – 5 km","Brookefield – 2 km"]}),

("flat-rental-hsr-layout.html","Flat for Rent in HSR Layout Bangalore | GharPayy",
 "Flat Rental in HSR Layout Bangalore","Premium fully furnished flats for rent in HSR Layout Bangalore. Zero brokerage, near Silk Board tech hub. 1BHK from ₹16k, 2BHK from ₹26k.",
 "rental","HSR Layout",{"type":"Flat","price_range":"1BHK: ₹16k–₹30k | 2BHK: ₹26k–₹50k","landmarks":["HSR Layout BDA Complex – 0.5 km","Silk Board – 2 km","Koramangala – 3 km","Agara Lake – 1.5 km","Electronic City – 6 km"]}),

("flat-rental-electronic-city.html","Flat for Rent in Electronic City Bangalore | GharPayy",
 "Flat Rental in Electronic City Bangalore","Affordable fully furnished flats for rent in Electronic City Bangalore near Infosys, Wipro. Zero brokerage. 1BHK from ₹12k, 2BHK from ₹18k.",
 "rental","Electronic City",{"type":"Flat","price_range":"1BHK: ₹12k–₹22k | 2BHK: ₹18k–₹32k","landmarks":["Electronic City Phase 1 – 0.5 km","Infosys Campus – 1 km","Hosa Road Metro – 2 km","Bommasandra – 3 km","Begur – 4 km"]}),

("flat-rental-indiranagar.html","Flat for Rent in Indiranagar Bangalore | GharPayy",
 "Flat Rental in Indiranagar Bangalore","Premium fully furnished flats for rent in Indiranagar Bangalore near 100ft Road, metro. Zero brokerage. 1BHK from ₹20k, 2BHK from ₹30k.",
 "rental","Indiranagar",{"type":"Flat","price_range":"1BHK: ₹20k–₹40k | 2BHK: ₹30k–₹60k","landmarks":["Indira Nagar Metro – 0.3 km","100ft Road – 0.2 km","HAL Airport Road – 2 km","Koramangala – 4 km","MG Road – 3 km"]}),

# ───── BATCH 5 — Special Keyword Pages ─────
("co-living-in-sarjapur.html","Premium Co-living in Sarjapur Bangalore | GharPayy",
 "Co-living Spaces in Sarjapur Bangalore","Premium co-living in Sarjapur Road Bangalore near Wipro, RMZ Ecospace. Community-focused managed housing for IT professionals. From ₹7,000/month, zero brokerage.",
 "special","Sarjapur",{"subtype":"co-living","landmarks":["Wipro Campus – 1.5 km","RMZ Ecospace – 3 km","Sarjapur Road ORR – 1 km","Forum Mall – 6 km","Carmelaram – 2 km"]}),

("co-living-in-marathahalli.html","Premium Co-living in Marathahalli Bangalore | GharPayy",
 "Co-living Spaces in Marathahalli Bangalore","Premium co-living spaces in Marathahalli Bangalore near ITPL, Divyasree, ORR tech companies. Managed community housing from ₹7,000/month, zero brokerage.",
 "special","Marathahalli",{"subtype":"co-living","landmarks":["Marathahalli Bridge – 0.3 km","ITPL – 4 km","Kundalahalli Gate Metro – 3 km","Domlur – 4 km","ORR – 0.2 km"]}),

("co-living-in-electronic-city.html","Premium Co-living in Electronic City Bangalore | GharPayy",
 "Co-living Spaces in Electronic City Bangalore","Managed co-living in Electronic City Bangalore near Infosys, Wipro, TCS. Community housing for IT professionals from ₹7,000/month, zero brokerage.",
 "special","Electronic City",{"subtype":"co-living","landmarks":["Electronic City Phase 1 – 0.5 km","Infosys Campus – 1 km","Hosa Road Metro – 2 km","Bommasandra – 3 km","Begur – 4 km"]}),

("co-living-in-jp-nagar.html","Premium Co-living in JP Nagar Bangalore | GharPayy",
 "Co-living Spaces in JP Nagar Bangalore","Premium co-living spaces in JP Nagar Bangalore near IBC Knowledge Park, Bannerghatta Road. Community housing from ₹7,000/month, zero brokerage.",
 "special","JP Nagar",{"subtype":"co-living","landmarks":["JP Nagar Phase 1 – 0.5 km","IBC Knowledge Park – 2 km","Bannerghatta Road – 1 km","Jayanagar – 3 km","Lalbagh – 4 km"]}),

("co-living-in-hebbal.html","Premium Co-living in Hebbal Bangalore | GharPayy",
 "Co-living Spaces in Hebbal Bangalore","Managed co-living in Hebbal Bangalore near Microsoft MSIDC, Manyata Tech Park. Community housing for tech professionals from ₹7,000/month, zero brokerage.",
 "special","Hebbal",{"subtype":"co-living","landmarks":["Microsoft MSIDC – 1.5 km","Manyata Tech Park – 3 km","Hebbal Lake – 0.5 km","Outer Ring Road – 1 km","Thanisandra Road – 2 km"]}),

("girls-pg-in-indiranagar.html","Safe Girls PG in Indiranagar Bangalore | GharPayy",
 "Girls PG in Indiranagar Bangalore","Safe, secure and fully furnished girls PG in Indiranagar Bangalore. CCTV, 24/7 security, near metro. Zero brokerage from ₹7,000/month.",
 "special","Indiranagar",{"subtype":"girls-pg","landmarks":["Indira Nagar Metro – 0.3 km","100ft Road – 0.2 km","HAL Airport Road – 2 km","Koramangala – 4 km","MG Road – 3 km"]}),

("girls-pg-in-jp-nagar.html","Safe Girls PG in JP Nagar Bangalore | GharPayy",
 "Girls PG in JP Nagar Bangalore","Safe fully furnished girls PG in JP Nagar Bangalore with CCTV, security. Zero brokerage from ₹7,000/month near IBC, Bannerghatta Road.",
 "special","JP Nagar",{"subtype":"girls-pg","landmarks":["JP Nagar Phase 1 Arch – 0.5 km","IBC Knowledge Park – 2 km","Bannerghatta Road – 1 km","Kumaraswamy Layout Metro – 2 km","Lalbagh – 4 km"]}),

("girls-pg-in-marathahalli.html","Safe Girls PG in Marathahalli Bangalore | GharPayy",
 "Girls PG in Marathahalli Bangalore","Safe, secure fully furnished girls PG in Marathahalli Bangalore. CCTV, 24/7 security near ORR tech corridor. Zero brokerage from ₹7,000/month.",
 "special","Marathahalli",{"subtype":"girls-pg","landmarks":["Marathahalli Bridge – 0.3 km","ITPL – 4 km","Kundalahalli Gate Metro – 3 km","Domlur – 4 km","ORR – 0.2 km"]}),

("girls-pg-in-hebbal.html","Safe Girls PG in Hebbal Bangalore | GharPayy",
 "Girls PG in Hebbal Bangalore","Safe fully furnished girls PG in Hebbal Bangalore with 24/7 security, CCTV. Near Microsoft, Manyata Tech Park. Zero brokerage from ₹7,000/month.",
 "special","Hebbal",{"subtype":"girls-pg","landmarks":["Microsoft MSIDC – 1.5 km","Manyata Tech Park – 3 km","Hebbal Lake – 0.5 km","Outer Ring Road – 1 km","Thanisandra Road – 2 km"]}),

("girls-pg-in-sarjapur.html","Safe Girls PG in Sarjapur Road Bangalore | GharPayy",
 "Girls PG in Sarjapur Road Bangalore","Safe secure fully furnished girls PG in Sarjapur Road Bangalore. CCTV, 24/7 security, near Wipro, RMZ. Zero brokerage from ₹7,000/month.",
 "special","Sarjapur",{"subtype":"girls-pg","landmarks":["Wipro Campus – 1.5 km","RMZ Ecospace – 3 km","Sarjapur Road ORR – 1 km","Forum Mall – 6 km","Carmelaram – 2 km"]}),

("boys-pg-in-sarjapur.html","Boys PG in Sarjapur Road Bangalore | GharPayy",
 "Boys PG in Sarjapur Road Bangalore","Fully furnished boys paying guest accommodation in Sarjapur Road Bangalore. Zero brokerage, near Wipro, RMZ. Hotel-like rooms from ₹7,000/month.",
 "special","Sarjapur",{"subtype":"boys-pg","landmarks":["Wipro Campus – 1.5 km","RMZ Ecospace – 3 km","Sarjapur Road ORR – 1 km","Forum Mall – 6 km","Carmelaram – 2 km"]}),

("boys-pg-in-marathahalli.html","Boys PG in Marathahalli Bangalore | GharPayy",
 "Boys PG in Marathahalli Bangalore","Fully furnished boys PG in Marathahalli Bangalore near ORR tech companies. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "special","Marathahalli",{"subtype":"boys-pg","landmarks":["Marathahalli Bridge – 0.3 km","ITPL – 4 km","Kundalahalli Gate Metro – 3 km","Domlur – 4 km","ORR – 0.2 km"]}),

("boys-pg-in-hebbal.html","Boys PG in Hebbal Bangalore | GharPayy",
 "Boys PG in Hebbal Bangalore","Fully furnished boys PG in Hebbal Bangalore near Microsoft, Manyata Tech Park. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "special","Hebbal",{"subtype":"boys-pg","landmarks":["Microsoft MSIDC – 1.5 km","Manyata Tech Park – 3 km","Hebbal Lake – 0.5 km","Outer Ring Road – 1 km","Thanisandra Road – 2 km"]}),

("boys-pg-in-jp-nagar.html","Boys PG in JP Nagar Bangalore | GharPayy",
 "Boys PG in JP Nagar Bangalore","Fully furnished boys paying guest accommodation in JP Nagar Bangalore. Zero brokerage hotel-like rooms from ₹7,000/month near IBC, Bannerghatta Road.",
 "special","JP Nagar",{"subtype":"boys-pg","landmarks":["JP Nagar Phase 1 Arch – 0.5 km","IBC Knowledge Park – 2 km","Bannerghatta Road – 1 km","Kumaraswamy Layout Metro – 2 km","Lalbagh – 4 km"]}),

("boys-pg-in-yeahwanthpur.html","Boys PG in Yeshwanthpur Bangalore | GharPayy",
 "Boys PG in Yeshwanthpur Bangalore","Fully furnished boys PG in Yeshwanthpur Bangalore near Yeshwanthpur Railway Station, Peenya Industrial Area. Zero brokerage hotel-like rooms from ₹7,000/month.",
 "special","Yeshwanthpur",{"subtype":"boys-pg","landmarks":["Yeshwanthpur Railway Station – 0.5 km","Peenya Metro – 3 km","IISc Gate – 4 km","Rajajinagar Metro – 2 km","Chord Road – 1 km"]}),

("luxury-pg-bangalore.html","Luxury PG in Bangalore 2025 | Hotel-Like Premium PG | GharPayy",
 "Luxury PG Accommodation in Bangalore","Experience hotel-like luxury PG in Bangalore with GharPayy. Premium furnished rooms, housekeeping, food, gym access. PRIVE ₹17k–₹26k, LUXE MAX ₹25k–₹45k. Zero brokerage.",
 "special","Bangalore",{"subtype":"luxury","landmarks":["Koramangala","Indiranagar","HSR Layout","Whitefield","Sarjapur Road"]}),

("affordable-pg-bangalore.html","Affordable PG in Bangalore from ₹7000 | GharPayy",
 "Affordable PG in Bangalore","Find affordable PG accommodation in Bangalore starting at ₹7,000/month. GharPayy BASIC tier — fully furnished, WiFi, food options. Zero brokerage across all areas.",
 "special","Bangalore",{"subtype":"affordable","landmarks":["Electronic City","Whitefield","Marathahalli","Sarjapur","HSR Layout"]}),

("furnished-pg-bangalore.html","Fully Furnished PG in Bangalore | GharPayy",
 "Fully Furnished PG in Bangalore","Find completely furnished PG accommodation across Bangalore with GharPayy. Bed, mattress, wardrobe, AC, WiFi, housekeeping included. From ₹7,000/month, zero brokerage.",
 "special","Bangalore",{"subtype":"furnished","landmarks":["Koramangala","Indiranagar","Whitefield","Electronic City","HSR Layout"]}),

("pg-with-food-bangalore.html","PG with Food in Bangalore | Meals Included PG | GharPayy",
 "PG with Food in Bangalore","Find PG accommodations with food included across Bangalore. GharPayy offers freshly prepared meals with all tiers. Breakfast, lunch, dinner options. From ₹7,000/month, zero brokerage.",
 "special","Bangalore",{"subtype":"food","landmarks":["Koramangala","Indiranagar","Whitefield","Electronic City","Marathahalli"]}),

("pg-with-wifi-bangalore.html","PG with WiFi in Bangalore | High-Speed Internet PG | GharPayy",
 "PG with WiFi in Bangalore","GharPayy PG accommodations across Bangalore come with high-speed WiFi included in all plans. Work from your room with 100 Mbps+ connectivity. From ₹7,000/month, zero brokerage.",
 "special","Bangalore",{"subtype":"wifi","landmarks":["Koramangala","Indiranagar","Whitefield","Electronic City","Sarjapur"]}),
]

# ─────────────── Internal link pool (all pages) ─────────────────────────────
ALL_LINKS = [(p[0], p[2]) for p in PAGES]

def get_explore_links(current_file, count=18):
    """Pick diverse internal links excluding current page."""
    links = [(f, t) for f, t in ALL_LINKS if f != current_file]
    # Spread across batches
    step = max(1, len(links) // count)
    selected = links[::step][:count]
    # Pad if needed
    if len(selected) < count:
        extras = [l for l in links if l not in selected]
        selected += extras[:count - len(selected)]
    return selected[:count]

# ─────────────── FAQ generator per page type ────────────────────────────────
def get_faqs(page_type, area, extra):
    if page_type == "area":
        return [
            (f"What is the monthly rent for PG in {area}, Bangalore?",
             f"GharPayy offers PG accommodation in {area}, Bangalore across four tiers: BASIC (₹7,000–₹11,000/month), CLASSICS (₹12,000–₹17,000/month), PRIVE (₹17,000–₹26,000/month), and LUXE MAX (₹25,000–₹45,000/month). All prices are zero brokerage."),
            (f"Is there zero brokerage PG in {area} Bangalore?",
             f"Yes! GharPayy is a 100% zero-brokerage PG provider. You never pay brokerage for any accommodation in {area} or anywhere across Bangalore. What you see is what you pay."),
            (f"Are there girls and boys PG options available in {area}?",
             f"GharPayy offers both girls and boys PG accommodations in {area}, Bangalore. All properties come with 24/7 security, CCTV, and secure entry systems."),
            (f"What amenities are included in GharPayy PG in {area}?",
             f"GharPayy PG in {area} includes fully furnished rooms, high-speed WiFi, housekeeping, power backup, and optional food (breakfast/dinner). Higher tiers include AC, attached bathrooms, gym access, and premium interiors."),
            (f"How do I book a PG in {area} through GharPayy?",
             f"You can book instantly via WhatsApp or schedule a site visit on our booking page at cal.com/gharpayy.com/stay. Our team responds within minutes during business hours."),
        ]
    elif page_type == "college":
        college = extra.get("college_full","the college")
        return [
            (f"What is the rent for student PG near {area}?",
             f"GharPayy offers student-friendly PG near {area} starting at ₹7,000/month (BASIC tier). Ideal shared rooms are ₹9,000–₹11,000/month and semi-private rooms start at ₹12,000/month. Zero brokerage always."),
            (f"Is there girls PG near {area} with security?",
             f"Yes, GharPayy provides safe girls PG near {area} with 24/7 CCTV surveillance, biometric entry, and security personnel. Safety is non-negotiable at all our properties."),
            (f"How far is GharPayy PG from {area}?",
             f"GharPayy has properties within 0.5–3 km of {area}, ensuring students can walk, cycle or take a 10-minute auto/cab ride. We share exact distance on booking."),
            (f"Does GharPayy PG near {area} provide food?",
             f"Yes, food services are available at GharPayy PG near {area}. Freshly prepared breakfast and dinner options are available as add-ons. Some CLASSICS and higher tier rooms include meals in the rent."),
            (f"Can I get a single room PG near {area}?",
             f"GharPayy offers single occupancy rooms near {area} under our CLASSICS (₹12k–₹17k), PRIVE (₹17k–₹26k), and LUXE MAX (₹25k–₹45k) tiers. All single rooms are fully furnished with attached or shared bathrooms."),
        ]
    elif page_type == "company":
        company = extra.get("company_full","the company")
        return [
            (f"Is there PG walking distance from {area}?",
             f"Yes, GharPayy has properties within 0.5–2 km of {area}, making it walkable or a quick 5-minute cab ride. We share exact property addresses before booking."),
            (f"What is the rent for PG near {area}?",
             f"GharPayy PG near {area} starts at ₹7,000/month (BASIC tier shared). Most IT professionals prefer CLASSICS (₹12k–₹17k) for semi-private rooms or PRIVE (₹17k–₹26k) for private rooms with premium amenities."),
            (f"Is there zero brokerage PG near {area} Bangalore?",
             f"Absolutely. GharPayy is Bangalore's leading zero-brokerage PG provider. No hidden charges, no brokerage — ever. Near {area} or anywhere in Bangalore."),
            (f"Are furnished PG rooms available near {area}?",
             f"All GharPayy rooms near {area} are fully furnished including bed, mattress, wardrobe, study table, chair, WiFi, and power backup. CLASSICS+ tiers include AC."),
            (f"Can I tour the PG room near {area} before booking?",
             f"Yes! Schedule a free site visit via our booking link at cal.com/gharpayy.com/stay or message us on WhatsApp. Virtual room tours are also available on our YouTube channel @gharpayy."),
        ]
    elif page_type == "rental":
        bhk_type = extra.get("type","Flat")
        return [
            (f"What is the rent for {bhk_type} in {area} Bangalore?",
             f"GharPayy-managed {bhk_type} flats in {area} Bangalore are available at {extra.get('price_range','competitive market rates')}. All are zero brokerage, fully furnished, with maintenance support."),
            (f"Is there zero brokerage {bhk_type} for rent in {area}?",
             f"Yes! GharPayy offers 100% zero-brokerage {bhk_type} rentals in {area}, Bangalore. No brokerage, no hidden charges — just straightforward transparent pricing."),
            (f"Are {bhk_type} flats fully furnished in {area}?",
             f"GharPayy {bhk_type} rentals in {area} come fully furnished with all essential furniture, appliances, WiFi, and housekeeping. Move in immediately without buying anything."),
            (f"What is included in the {bhk_type} rent in {area}?",
             f"GharPayy {bhk_type} flat rentals in {area} include furnished interiors, high-speed WiFi, power backup, water, and basic housekeeping. Exact inclusions vary by property."),
            (f"How do I book a {bhk_type} in {area} through GharPayy?",
             f"Book instantly via WhatsApp or schedule a site visit at cal.com/gharpayy.com/stay. Our team will shortlist {bhk_type} options in {area} matching your budget and preferences within 24 hours."),
        ]
    else:  # special
        subtype = extra.get("subtype","pg")
        return [
            (f"What makes GharPayy the best PG option in {area}?",
             f"GharPayy offers hotel-like quality rooms with professional management in {area}. Zero brokerage, fully furnished, high-speed WiFi, food options, 24/7 support, and a premium community of like-minded professionals."),
            (f"What are the rent ranges for GharPayy in {area}?",
             f"GharPayy's four tiers cover all budgets: BASIC ₹7k–₹11k, CLASSICS ₹12k–₹17k, PRIVE ₹17k–₹26k, and LUXE MAX ₹25k–₹45k. Zero brokerage on all tiers."),
            (f"Does GharPayy offer {subtype.replace('-',' ')} in {area}?",
             f"Yes! GharPayy specializes in premium managed accommodation in {area}, Bangalore tailored for working professionals and students. All properties are safe, modern, and fully serviced."),
            (f"How quickly can I move into a GharPayy PG in {area}?",
             f"Most GharPayy rooms are ready for immediate occupancy. Book via WhatsApp or our booking portal and you can move in within 24–48 hours after verification."),
            (f"Is WiFi and food included in GharPayy PG in {area}?",
             f"High-speed WiFi is included in all GharPayy rooms. Food options (breakfast/dinner) are available at an additional charge or bundled in select CLASSICS and higher-tier plans."),
        ]

# ─────────────── Content generator per page type ────────────────────────────
def get_content(page_type, area, title, extra):
    hub = extra.get("hub","Bangalore")
    if page_type == "area":
        return f"""
<div class="prose">
  <h2>Premium PG Accommodation in {area}, Bangalore</h2>
  <p>{area} is one of Bangalore's fastest-growing residential and commercial zones, situated in the <strong>{hub}</strong>. With rapid infrastructure development and proximity to major tech corridors, {area} has become a hotspot for IT professionals, startup employees, and young working adults seeking quality accommodation.</p>
  <p>GharPayy brings its signature <em>hotel-kinda PG</em> experience to {area}, offering fully managed, zero-brokerage accommodation that blends the comfort of a hotel with the community spirit of co-living. Whether you're a fresher joining your first job or an experienced professional relocating to Bangalore, GharPayy's PG in {area} is your ideal home away from home.</p>

  <h3>Why Choose GharPayy PG in {area}?</h3>
  <ul>
    <li>Zero brokerage — pay no middleman charges, ever</li>
    <li>Fully furnished rooms with bed, mattress, wardrobe, study table, AC (in CLASSICS+)</li>
    <li>High-speed WiFi (100 Mbps+) included in all plans</li>
    <li>24/7 CCTV surveillance, biometric entry, and security personnel</li>
    <li>Daily/weekly housekeeping services</li>
    <li>Food options — freshly prepared breakfast and dinner available</li>
    <li>Power backup for uninterrupted living</li>
    <li>Professional community of IT professionals, students, and startup employees</li>
  </ul>

  <h3>Location Advantages of {area}</h3>
  <p>Living in {area} puts you at the heart of Bangalore's growth story. The area offers excellent connectivity to major tech parks, metro stations, and entertainment zones. Residents enjoy access to supermarkets, hospitals, restaurants, gyms, and weekend activity spots — all within a short distance.</p>
  <p>With GharPayy's PG in {area}, your commute to work becomes shorter, your living costs become predictable, and your quality of life improves dramatically. Our carefully selected properties in {area} are positioned for minimal commute to the area's key employment destinations.</p>

  <h3>PG Accommodation Options in {area} for Working Professionals</h3>
  <p>GharPayy offers shared PG rooms {area} affordable for freshers and private rooms for senior professionals seeking more privacy. Our <strong>BASIC tier</strong> (₹7k–₹11k) is perfect for budget-conscious residents, while <strong>CLASSICS</strong> (₹12k–₹17k) offers semi-private rooms with enhanced amenities. The <strong>PRIVE tier</strong> (₹17k–₹26k) delivers private rooms with premium interiors, and our <strong>LUXE MAX</strong> (₹25k–₹45k) is the pinnacle of luxury PG living — hotel-like in every sense.</p>

  <h3>PG Accommodation in {area} for Students</h3>
  <p>Students from nearby colleges and coaching institutes also find GharPayy {area} to be an ideal base. Our properties are safe, equipped with high-speed internet for online learning, and foster a disciplined, positive community environment. Fully furnished single room PG {area} Bangalore options are available in all price ranges.</p>

  <h3>Co-living in {area} Bangalore</h3>
  <p>Beyond traditional PG, GharPayy {area} functions as a vibrant co-living community. Residents share common spaces, attend community events, and build meaningful professional and personal connections. Co-living spaces {area} Bangalore for IT professionals are thoughtfully designed to balance private time with community interaction.</p>

  <h3>Zero Brokerage PG in {area} — How It Works</h3>
  <p>When you book through GharPayy, you deal directly with us — no brokers, no middlemen. Zero brokerage PG {area} for working professionals means you save 1–2 months' rent that would otherwise go to brokers. Our transparent pricing includes everything upfront.</p>
</div>"""

    elif page_type == "college":
        college_full = extra.get("college_full","the institution")
        college_area = extra.get("college_area","the area")
        courses = extra.get("courses","various programs")
        return f"""
<div class="prose">
  <h2>Student PG near {area}, Bangalore</h2>
  <p><strong>{college_full}</strong>, located in {college_area}, Bangalore, is one of the most sought-after institutions in Karnataka. Students enrolled in <em>{courses}</em> seek quality accommodation near campus that is safe, affordable, and conducive to academic success.</p>
  <p>GharPayy provides premium student PG near {area} with all the amenities modern students need — high-speed WiFi, study zones, nutritious food, and 24/7 security — at transparent zero-brokerage pricing.</p>

  <h3>Why Students Choose GharPayy Near {area}</h3>
  <ul>
    <li>Close proximity to {college_full} — 5–20 minute commute</li>
    <li>High-speed WiFi (100 Mbps+) for assignments, online classes, and research</li>
    <li>Safe environment: 24/7 CCTV, biometric entry, security personnel</li>
    <li>Mess/food services with nutritious freshly cooked meals</li>
    <li>Fully furnished rooms — no furniture purchases needed</li>
    <li>Zero brokerage — save your first month's rent upfront</li>
    <li>Community of fellow students and young professionals</li>
    <li>Study-friendly quiet zones in common areas</li>
  </ul>

  <h3>About {college_full}</h3>
  <p>{college_full} is a premier institution in {college_area} offering {courses}. The institution is known for its rigorous academics, experienced faculty, and excellent placement record with top companies. Students coming from outside Bangalore or Karnataka especially need quality accommodation nearby.</p>

  <h3>Girls Hostel Near {area} — Safe & Secure</h3>
  <p>GharPayy's girls PG near {area} is equipped with female-only floors or wings, additional security measures, and a community of like-minded women professionals and students. Parents trust GharPayy because of our transparent management and 24/7 monitoring.</p>

  <h3>Boys PG Near {area} — Comfortable & Affordable</h3>
  <p>Boys PG near {area} at GharPayy offers clean, modern rooms with all essentials included. From budget-friendly shared rooms to premium single occupancy options — there's something for every student budget.</p>

  <h3>Paying Guest Accommodation {area} Bangalore — What to Expect</h3>
  <p>Unlike traditional paying guest setups, GharPayy functions as a managed co-living brand. Residents get professional-grade housekeeping, maintenance support, and a dedicated community manager. This is PG as it should be — Personal Growth, not just Paying Guest.</p>
</div>"""

    elif page_type == "company":
        company_full = extra.get("company_full","the company")
        company_area = extra.get("company_area","the area")
        about = extra.get("about","A leading technology company.")
        return f"""
<div class="prose">
  <h2>PG Accommodation near {area}, Bangalore</h2>
  <p><strong>{company_full}</strong> is based in {company_area}, Bangalore. {about}</p>
  <p>Professionals joining or working at {area} often look for quality PG accommodation nearby that eliminates long commutes, offers hotel-like comfort, and fits within a working professional's budget. GharPayy is the answer — zero brokerage PG near {area} Bangalore with premium managed rooms starting at ₹7,000/month.</p>

  <h3>Why Professionals Near {area} Choose GharPayy</h3>
  <ul>
    <li>Short commute — within 0.5 to 3 km of {area}</li>
    <li>Zero brokerage — no broker fees, ever</li>
    <li>Fully furnished rooms with AC, WiFi, power backup</li>
    <li>Professional community of fellow IT and startup employees</li>
    <li>Monthly rent model — no long-term lease commitment</li>
    <li>Food options, housekeeping, and maintenance included</li>
    <li>Startup employee PG near {area} — flexible, modern, affordable</li>
  </ul>

  <h3>Startup Employee PG near {area}</h3>
  <p>Working at a fast-growing company like those in {company_area} means long hours and demanding work schedules. GharPayy removes the burden of managing your home so you can focus on your career. Our managed PG accommodation {area} monthly keeps your living experience predictable and stress-free.</p>

  <h3>Accommodation Near {area} Office — Distance & Connectivity</h3>
  <p>GharPayy properties near {area} are strategically located to minimize your commute time. Most properties are accessible via metro, auto, cab, or on foot from {area}. We provide exact distances and directions when you book.</p>

  <h3>PG for Bangalore Freshers Near {area}</h3>
  <p>First-time Bangalore residents joining {area} as freshers can move into GharPayy PG immediately without any setup cost. All rooms are ready-to-move-in, fully furnished, and come with a friendly community of fellow professionals.</p>

  <h3>Hotel-Like PG Near {area}</h3>
  <p>GharPayy's tagline <em>#Hotel_kinda_PG</em> is no accident. Every property near {area} is designed to deliver hotel-grade comfort — premium mattresses, tasteful interiors, spotless housekeeping, and professional management. This is PG accommodation that you'll actually look forward to coming home to.</p>
</div>"""

    elif page_type == "rental":
        bhk_type = extra.get("type","Flat")
        price_range = extra.get("price_range","competitive market rates")
        return f"""
<div class="prose">
  <h2>{bhk_type} Rental Options in {area}, Bangalore</h2>
  <p>Looking for a {bhk_type} flat for rent in {area}, Bangalore? GharPayy offers premium managed {bhk_type} rentals in {area} with zero brokerage, fully furnished interiors, and professional maintenance support. Rent ranges from {price_range}.</p>
  <p>{area} is one of Bangalore's most desirable residential neighbourhoods with excellent connectivity, dining options, shopping centres, and access to major tech employment corridors. A {bhk_type} in {area} gives you both comfort and convenience.</p>

  <h3>Why Rent a {bhk_type} in {area} Through GharPayy?</h3>
  <ul>
    <li>Zero brokerage — 1BHK flat on rent {area} Bangalore without brokerage</li>
    <li>Fully furnished — bed, wardrobe, sofa, dining table, kitchen appliances</li>
    <li>High-speed WiFi included in all plans</li>
    <li>Professional housekeeping and maintenance support</li>
    <li>Transparent monthly pricing with no hidden charges</li>
    <li>Immediate occupancy — move in within 24 hours of booking</li>
    <li>2BHK rental {area} Bangalore fully furnished options also available</li>
  </ul>

  <h3>{bhk_type} Rent Prices in {area} Bangalore</h3>
  <p>GharPayy {bhk_type} flats in {area} are priced at {price_range}. This includes furnishing, maintenance, WiFi, and in some units, utilities. Contact our team for the latest availability and pricing for specific layouts.</p>

  <h3>Fully Furnished vs Unfurnished {bhk_type} in {area}</h3>
  <p>GharPayy exclusively manages fully furnished {bhk_type} flats in {area}. You don't need to spend ₹50,000–₹1,50,000 buying furniture when you move in. Everything from the bed frame to the refrigerator is provided — just bring your clothes and personal items.</p>

  <h3>Managed Rental Living in {area}</h3>
  <p>Unlike dealing directly with individual landlords, GharPayy functions as a professional property manager. Any maintenance issues — electrical, plumbing, appliances — are resolved within 24 hours. This is managed PG accommodation {area} monthly, but for full flat rentals too.</p>

  <h3>Who Rents {bhk_type} Flats in {area}?</h3>
  <p>GharPayy {bhk_type} rentals in {area} are popular with young couples, working professional roommates, and individuals seeking more space and privacy than a PG room offers. The {area} location ensures excellent access to {', '.join([l.split(' – ')[0] for l in extra.get('landmarks',[])])}, making daily commutes manageable.</p>
</div>"""

    else:  # special
        subtype = extra.get("subtype","pg")
        s_map = {"co-living":"co-living spaces","girls-pg":"safe girls PG","boys-pg":"boys paying guest","luxury":"luxury PG","affordable":"affordable PG","furnished":"fully furnished PG","food":"PG with food","wifi":"PG with WiFi"}
        desc = s_map.get(subtype, "PG accommodation")
        return f"""
<div class="prose">
  <h2>{desc.title()} in {area} — GharPayy</h2>
  <p>GharPayy offers premium {desc} in {area}, Bangalore, designed for modern working professionals and students who expect more from their accommodation. Every property under our management delivers hotel-like quality at transparent, zero-brokerage pricing.</p>
  <p>Whether you're looking for a safe environment, community living experience, luxury amenities, or simply reliable WiFi and food — GharPayy has a tier that fits your needs and budget. Our four pricing tiers (BASIC, CLASSICS, PRIVE, LUXE MAX) cover the full spectrum from ₹7,000 to ₹45,000/month.</p>

  <h3>What Makes GharPayy's {desc.title()} in {area} Special?</h3>
  <ul>
    <li>Hotel-grade rooms: premium mattresses, tasteful interiors, spotless housekeeping</li>
    <li>Zero brokerage — no broker, no hidden fees</li>
    <li>High-speed WiFi 100 Mbps+ for work from room</li>
    <li>24/7 CCTV, biometric entry, security personnel</li>
    <li>Freshly prepared food options (breakfast + dinner)</li>
    <li>Power backup, laundry, and maintenance services</li>
    <li>Vibrant professional community — meet your next co-founder or best friend</li>
    <li>Community manager on-site for immediate assistance</li>
  </ul>

  <h3>GharPayy — Where PG Stands for Personal Growth</h3>
  <p>At GharPayy, we believe where you live shapes who you become. That's why we obsess over every detail — the quality of your mattress, the speed of your WiFi, the food on your table, and the people you share your home with. Our tagline <em>"Where PG Stands for Personal Growth"</em> isn't just marketing — it's our mission.</p>
  <p>Premium co-living {area} with amenities means you have more energy and headspace for what matters: your career, your relationships, and your personal goals. Let GharPayy handle the logistics of living so you can focus on growing.</p>

  <h3>Zero Brokerage PG in {area} for Working Professionals</h3>
  <p>Every day we see professionals waste one to two months' rent on brokerage fees just to find a place to live. At GharPayy, zero brokerage is a founding principle, not a promotional offer. When you book through us, every rupee goes toward your accommodation — none to a middleman.</p>

  <h3>Book in Minutes — Move in Within 24 Hours</h3>
  <p>Our booking process is frictionless. Message us on WhatsApp, schedule a visit via our booking portal, or call us directly. Once you decide, documentation is minimal and you can move in within 24–48 hours. No complex lease negotiations, no lengthy paperwork.</p>
</div>"""

# ─────────────── HTML page builder ──────────────────────────────────────────
def build_page(filename, title, h1_text, meta_desc, page_type, area, extra):
    explore = get_explore_links(filename)
    faqs = get_faqs(page_type, area, extra)
    content = get_content(page_type, area, h1_text, extra)
    landmarks = extra.get("landmarks", [f"Metro Station – 1 km", f"Tech Park – 2 km", f"Shopping Mall – 3 km"])

    # Breadcrumb label
    bc_label = h1_text

    # Schema type
    schema_name = f"GharPayy PG near {area}, Bangalore"

    # FAQ schema
    faq_schema_items = ",\n".join([
        f'{{"@type":"Question","name":{json.dumps(q)},"acceptedAnswer":{{"@type":"Answer","text":{json.dumps(a)}}}}}'
        for q, a in faqs
    ])

    # Explore links HTML
    explore_html = "\n".join([
        f'<a class="explore-link" href="{f}">{t}</a>'
        for f, t in explore
    ])

    # Location items HTML
    loc_html = "\n".join([
        f'''<div class="location-item"><span class="icon">📍</span><div class="details"><div class="name">{l.split(" – ")[0]}</div><div class="dist">{l.split(" – ")[1] if " – " in l else "Nearby"}</div></div></div>'''
        for l in landmarks
    ])

    # FAQ HTML
    faq_html = "\n".join([
        f'''<div class="faq-item"><div class="faq-q">{q}<span class="arrow">▼</span></div><div class="faq-a">{a}</div></div>'''
        for q, a in faqs
    ])

    # Keywords meta
    kw_map = {
        "area": f"PG in {area} Bangalore, paying guest {area}, zero brokerage PG {area}, furnished PG {area}, co-living {area} Bangalore, girls PG {area}, boys PG {area}, PG accommodation {area}",
        "college": f"PG near {area}, student PG {area} Bangalore, girls hostel near {area}, boys hostel near {area}, accommodation near {area} college",
        "company": f"PG near {area} Bangalore, accommodation near {area} office, PG walking distance {area}, startup employee PG {area}",
        "rental": f"{extra.get('type','flat')} for rent {area} Bangalore, furnished flat {area}, zero brokerage flat {area}, {extra.get('type','flat')} rent {area}",
        "special": f"PG in {area} Bangalore, premium PG {area}, co-living {area}, GharPayy {area}, best PG {area} Bangalore",
    }
    keywords = kw_map.get(page_type, f"PG in {area} Bangalore")

    # Hero subheadline based on type
    sub_map = {
        "area": f"Hotel-like furnished rooms in {area} with food, WiFi & zero brokerage. Rooms from ₹7,000/month — BASIC to LUXE MAX.",
        "college": f"Safe, furnished student PG near {area} with high-speed WiFi, food & 24/7 security. Zero brokerage from ₹7,000/month.",
        "company": f"Zero brokerage furnished PG near {area} for working professionals. Minimal commute, hotel-like comfort from ₹7,000/month.",
        "rental": f"Fully furnished {extra.get('type','flat')} rentals in {area} with zero brokerage. Move-in ready, professional management.",
        "special": f"Premium managed PG in {area}, Bangalore. Fully furnished, food, WiFi & zero brokerage. Personal Growth starts here.",
    }
    hero_sub = sub_map.get(page_type, f"Premium PG in {area}, Bangalore from ₹7,000/month.")

    # Chip labels
    chip1 = area if len(area) < 25 else area[:22]+"…"
    chip2 = "₹7k – ₹45k/mo"
    chip3 = "4.8★ Rating"
    chip4 = "Zero Brokerage"

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
{ATTRIB}
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<meta name="description" content="{meta_desc}">
<meta name="keywords" content="{keywords}">
<meta name="robots" content="index, follow">
<link rel="canonical" href="https://gharpayy.com/{filename}">
<!-- Open Graph -->
<meta property="og:title" content="{title}">
<meta property="og:description" content="{meta_desc}">
<meta property="og:image" content="https://gharpayy.com/img/logo/gharpayy_logo2.png">
<meta property="og:url" content="https://gharpayy.com/{filename}">
<meta property="og:type" content="website">
<meta property="og:site_name" content="GharPayy">
<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{title}">
<meta name="twitter:description" content="{meta_desc}">
<meta name="twitter:image" content="https://gharpayy.com/img/logo/gharpayy_logo2.png">
<!-- Stylesheet -->
<link rel="stylesheet" href="shared.css">
<!-- Schema Markup -->
<script type="application/ld+json">
{{
  "@context":"https://schema.org",
  "@graph":[
    {{
      "@type":"LocalBusiness",
      "name":"GharPayy — PG in {area} Bangalore",
      "description":"{meta_desc}",
      "url":"https://gharpayy.com/{filename}",
      "telephone":"{PHONE}",
      "address":{{"@type":"PostalAddress","addressLocality":"{area}","addressRegion":"Karnataka","addressCountry":"IN"}},
      "image":"{LOGO}",
      "priceRange":"₹7,000–₹45,000/month",
      "openingHours":"Mo-Su 00:00-24:00",
      "sameAs":["https://www.youtube.com/@gharpayy"],
      "creator":{{"@type":"SoftwareApplication","name":"Perplexity Computer","url":"https://www.perplexity.ai/computer"}}
    }},
    {{
      "@type":"BreadcrumbList",
      "itemListElement":[
        {{"@type":"ListItem","position":1,"name":"GharPayy","item":"https://gharpayy.com/"}},
        {{"@type":"ListItem","position":2,"name":"Bangalore PG","item":"https://gharpayy.com/index.html"}},
        {{"@type":"ListItem","position":3,"name":"{bc_label}","item":"https://gharpayy.com/{filename}"}}
      ]
    }},
    {{
      "@type":"FAQPage",
      "mainEntity":[{faq_schema_items}]
    }}
  ]
}}
</script>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar" role="navigation" aria-label="Main Navigation">
  <div class="container">
    <a class="navbar-logo" href="index.html" aria-label="GharPayy Home">
      <img src="{LOGO}" alt="GharPayy Logo" width="140" height="38">
    </a>
    <div class="navbar-cta">
      <a class="btn btn-outline btn-sm" href="{WHATSAPP}" target="_blank" rel="noopener">💬 Talk Now</a>
      <a class="btn btn-gold btn-sm" href="{BOOKING}" target="_blank" rel="noopener">📅 Stay Here</a>
    </div>
  </div>
</nav>

<!-- BREADCRUMB -->
<nav class="breadcrumb" aria-label="Breadcrumb">
  <div class="container">
    <ol itemscope itemtype="https://schema.org/BreadcrumbList">
      <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
        <a itemprop="item" href="index.html"><span itemprop="name">GharPayy</span></a>
        <meta itemprop="position" content="1">
      </li>
      <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
        <a itemprop="item" href="index.html"><span itemprop="name">Bangalore PG</span></a>
        <meta itemprop="position" content="2">
      </li>
      <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
        <span itemprop="name" aria-current="page">{bc_label}</span>
        <meta itemprop="position" content="3">
      </li>
    </ol>
  </div>
</nav>

<!-- HERO -->
<section class="hero" aria-labelledby="hero-h1">
  <div class="container">
    <div class="hero-inner">
      <div class="hero-badge">🏨 #Hotel_kinda_PG</div>
      <h1 id="hero-h1">{h1_text}</h1>
      <p class="hero-sub">{hero_sub}</p>
      <div class="hero-chips">
        <span class="chip gold">📍 {chip1}</span>
        <span class="chip gold">💰 {chip2}</span>
        <span class="chip green">⭐ {chip3}</span>
        <span class="chip green">✅ {chip4}</span>
      </div>
      <div class="cta-group">
        <a class="btn btn-gold btn-lg" href="{WHATSAPP}" target="_blank" rel="noopener">💬 Talk Now</a>
        <a class="btn btn-outline btn-lg" href="{BOOKING}" target="_blank" rel="noopener">📅 Stay Here</a>
        <a class="btn btn-ghost btn-lg" href="{TEL}">📞 Call Now</a>
      </div>
    </div>
  </div>
</section>

<!-- STATS STRIP -->
<div class="stats-strip" aria-label="GharPayy Key Stats">
  <div class="container">
    <div class="stats-grid">
      <div class="stat-item"><div class="value">500+</div><div class="label">Happy Residents</div></div>
      <div class="stat-item"><div class="value">₹0</div><div class="label">Brokerage Always</div></div>
      <div class="stat-item"><div class="value">4.8★</div><div class="label">Average Rating</div></div>
      <div class="stat-item"><div class="value">24/7</div><div class="label">Support</div></div>
      <div class="stat-item"><div class="value">30+</div><div class="label">Locations</div></div>
    </div>
  </div>
</div>

<!-- LOCATION INTELLIGENCE -->
<section class="section" aria-labelledby="location-h2">
  <div class="container">
    <div class="section-header">
      <span class="eyebrow">📍 Location Intelligence</span>
      <h2 id="location-h2">Key Landmarks Near {area}</h2>
      <div class="gold-line"></div>
      <p>Distance estimates from GharPayy properties in {area}, Bangalore</p>
    </div>
    <div class="location-grid">
      {loc_html}
    </div>
  </div>
</section>

<!-- PRICING SECTION -->
<section class="section content-section" aria-labelledby="pricing-h2">
  <div class="container">
    <div class="section-header">
      <span class="eyebrow">💰 Transparent Pricing</span>
      <h2 id="pricing-h2">Choose Your Tier in {area}</h2>
      <div class="gold-line"></div>
      <p>All plans include WiFi, housekeeping, and power backup. Zero brokerage always.</p>
    </div>
    <div class="pricing-grid">
      <div class="price-card">
        <div class="tier-name">BASIC</div>
        <div class="tier-price">₹7k–₹11k <span>/month</span></div>
        <div class="tier-desc">Shared rooms, essential amenities</div>
        <ul class="tier-features">
          <li>Shared room (2–3 occupants)</li>
          <li>High-speed WiFi</li>
          <li>Fan / non-AC</li>
          <li>Common bathroom</li>
          <li>Weekly housekeeping</li>
          <li>Power backup</li>
        </ul>
      </div>
      <div class="price-card featured">
        <div class="badge-popular">MOST POPULAR</div>
        <div class="tier-name">CLASSICS</div>
        <div class="tier-price">₹12k–₹17k <span>/month</span></div>
        <div class="tier-desc">Semi-private rooms with AC</div>
        <ul class="tier-features">
          <li>Double / semi-private room</li>
          <li>AC included</li>
          <li>High-speed WiFi</li>
          <li>Daily housekeeping</li>
          <li>Power backup</li>
          <li>Attached / shared bathroom</li>
        </ul>
      </div>
      <div class="price-card">
        <div class="tier-name">PRIVE</div>
        <div class="tier-price">₹17k–₹26k <span>/month</span></div>
        <div class="tier-desc">Private rooms, premium interiors</div>
        <ul class="tier-features">
          <li>Private single room</li>
          <li>AC + premium mattress</li>
          <li>Attached bathroom</li>
          <li>Daily housekeeping</li>
          <li>Smart TV (select rooms)</li>
          <li>Gym access (select properties)</li>
        </ul>
      </div>
      <div class="price-card">
        <div class="tier-name">LUXE MAX</div>
        <div class="tier-price">₹25k–₹45k <span>/month</span></div>
        <div class="tier-desc">Hotel-like luxury, all inclusive</div>
        <ul class="tier-features">
          <li>Luxury private suite</li>
          <li>Premium AC + mattress</li>
          <li>En-suite luxury bathroom</li>
          <li>Daily housekeeping</li>
          <li>Smart TV + work desk</li>
          <li>Gym + recreation access</li>
        </ul>
      </div>
    </div>
    <div style="margin-top:1.5rem; text-align:center;">
      <span class="zero-brokerage-badge">✅ Zero Brokerage on ALL tiers</span>
    </div>
  </div>
</section>

<!-- CONTENT BLOCK -->
<section class="section" aria-labelledby="content-h2">
  <div class="container">
    {content}
  </div>
</section>

<!-- FAQ SECTION -->
<section class="section content-section" aria-labelledby="faq-h2">
  <div class="container">
    <div class="section-header">
      <span class="eyebrow">❓ Frequently Asked</span>
      <h2 id="faq-h2">Common Questions — {area}</h2>
      <div class="gold-line"></div>
    </div>
    <div class="faq-list">
      {faq_html}
    </div>
  </div>
</section>

<!-- ALSO EXPLORE -->
<section class="section" aria-labelledby="explore-h2">
  <div class="container">
    <div class="section-header">
      <span class="eyebrow">🗺️ Also Explore</span>
      <h2 id="explore-h2">More GharPayy Locations in Bangalore</h2>
      <div class="gold-line"></div>
    </div>
    <div class="explore-grid">
      {explore_html}
    </div>
  </div>
</section>

<!-- CTA STRIP -->
<section class="cta-strip" aria-labelledby="cta-h2">
  <div class="container">
    <h2 id="cta-h2">Ready to Find Your Perfect PG in {area}?</h2>
    <p>Join 500+ happy residents living the GharPayy way. Zero brokerage, hotel-like rooms, vibrant community.</p>
    <div class="cta-group">
      <a class="btn btn-gold btn-lg" href="{WHATSAPP}" target="_blank" rel="noopener">💬 Talk Now — WhatsApp</a>
      <a class="btn btn-outline btn-lg" href="{BOOKING}" target="_blank" rel="noopener">📅 Book a Visit</a>
      <a class="btn btn-ghost btn-lg" href="{TEL}">📞 +91 83073 96042</a>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer class="footer" role="contentinfo">
  <div class="container">
    <div class="footer-grid">
      <div>
        <div class="footer-logo">
          <a href="index.html"><img src="{LOGO}" alt="GharPayy Logo" width="130" height="36"></a>
        </div>
        <p class="footer-tagline">Where PG Stands for Personal Growth<br><strong style="color:var(--gold)">#Hotel_kinda_PG</strong></p>
        <p class="footer-tagline" style="margin-top:0.75rem;">Bangalore's premium zero-brokerage PG &amp; co-living brand.</p>
      </div>
      <div class="footer-col">
        <h4>Top Areas</h4>
        <ul>
          <li><a href="pg-in-sarjapur.html">PG in Sarjapur</a></li>
          <li><a href="pg-in-brookefield.html">PG in Brookefield</a></li>
          <li><a href="pg-in-mahadevapura.html">PG in Mahadevapura</a></li>
          <li><a href="pg-in-horamavu.html">PG in Horamavu</a></li>
          <li><a href="pg-in-hennur.html">PG in Hennur</a></li>
          <li><a href="pg-in-devanahalli.html">PG in Devanahalli</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Tech Parks</h4>
        <ul>
          <li><a href="pg-near-wipro-campus-sarjapur.html">Near Wipro Sarjapur</a></li>
          <li><a href="pg-near-infosys-electronic-city.html">Near Infosys EC</a></li>
          <li><a href="pg-near-microsoft-bangalore.html">Near Microsoft</a></li>
          <li><a href="pg-near-google-bangalore.html">Near Google</a></li>
          <li><a href="pg-near-embassy-tech-village.html">Near Embassy Tech</a></li>
          <li><a href="pg-near-flipkart-bangalore.html">Near Flipkart HQ</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Contact</h4>
        <ul>
          <li><a href="{WHATSAPP}" target="_blank" rel="noopener">💬 WhatsApp Us</a></li>
          <li><a href="{TEL}">📞 +91 83073 96042</a></li>
          <li><a href="{BOOKING}" target="_blank" rel="noopener">📅 Book a Visit</a></li>
          <li><a href="https://www.youtube.com/@gharpayy" target="_blank" rel="noopener">▶ YouTube</a></li>
          <li><a href="index.html">🗺️ All Locations</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© 2025 GharPayy. All rights reserved. Zero Brokerage Always.</span>
      <a href="https://www.perplexity.ai/computer" target="_blank" rel="noopener noreferrer" style="color:var(--muted);">Created with Perplexity Computer</a>
    </div>
  </div>
</footer>

<!-- FAQ Toggle JS -->
<script>
document.querySelectorAll('.faq-q').forEach(function(q) {{
  q.addEventListener('click', function() {{
    var item = q.closest('.faq-item');
    item.classList.toggle('open');
  }});
}});
</script>
</body>
</html>"""
    return html

# ─────────────── Master Index Page ──────────────────────────────────────────
def build_index():
    # Group pages by type
    area_pages = [(f,t) for f,_,t,_,pt,_,_ in [(p[0],p[1],p[2],p[3],p[4],p[5],p[6]) for p in PAGES] if pt == "area"]
    college_pages = [(f,t) for f,_,t,_,pt,_,_ in [(p[0],p[1],p[2],p[3],p[4],p[5],p[6]) for p in PAGES] if pt == "college"]
    company_pages = [(f,t) for f,_,t,_,pt,_,_ in [(p[0],p[1],p[2],p[3],p[4],p[5],p[6]) for p in PAGES] if pt == "company"]
    rental_pages = [(f,t) for f,_,t,_,pt,_,_ in [(p[0],p[1],p[2],p[3],p[4],p[5],p[6]) for p in PAGES] if pt == "rental"]
    special_pages = [(f,t) for f,_,t,_,pt,_,_ in [(p[0],p[1],p[2],p[3],p[4],p[5],p[6]) for p in PAGES] if pt == "special"]

    def link_list(pages):
        return "\n".join([f'<li><a href="{f}">{t}</a></li>' for f, t in pages])

    faq_schema = json.dumps([
        {"@type":"Question","name":"What is GharPayy?","acceptedAnswer":{"@type":"Answer","text":"GharPayy is Bangalore's premium zero-brokerage PG and co-living brand offering hotel-like managed accommodation for working professionals and students. We operate across 30+ areas in Bangalore with four pricing tiers from ₹7,000 to ₹45,000/month."}},
        {"@type":"Question","name":"Does GharPayy charge brokerage?","acceptedAnswer":{"@type":"Answer","text":"No. GharPayy is a 100% zero-brokerage PG brand. You never pay brokerage fees when booking through us — anywhere in Bangalore, for any tier."}},
        {"@type":"Question","name":"What is the cheapest PG at GharPayy?","acceptedAnswer":{"@type":"Answer","text":"GharPayy's BASIC tier starts at ₹7,000/month and goes up to ₹11,000/month for shared rooms with essential amenities including WiFi and power backup."}},
        {"@type":"Question","name":"Does GharPayy provide food?","acceptedAnswer":{"@type":"Answer","text":"Yes, food options are available at GharPayy properties. Freshly prepared breakfast and dinner are available as add-ons or bundled in select CLASSICS and higher tier plans."}},
        {"@type":"Question","name":"How do I book a GharPayy PG?","acceptedAnswer":{"@type":"Answer","text":"You can book via WhatsApp at +918307396042, schedule a site visit at cal.com/gharpayy.com/stay, or call us directly. Our team responds within minutes."}}
    ])

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
{ATTRIB}
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>GharPayy — Best PG in Bangalore | Zero Brokerage | Hotel-Like PG | 30+ Areas</title>
<meta name="description" content="GharPayy is Bangalore's #1 zero-brokerage premium PG and co-living brand. Hotel-like furnished rooms from ₹7,000/month across 30+ areas near top tech parks, colleges & companies. #Hotel_kinda_PG">
<meta name="keywords" content="PG in Bangalore, zero brokerage PG Bangalore, co-living Bangalore, best PG Bangalore 2025, furnished PG Bangalore, paying guest Bangalore, girls PG Bangalore, boys PG Bangalore, PG near IT companies Bangalore, GharPayy">
<meta name="robots" content="index, follow">
<link rel="canonical" href="https://gharpayy.com/">
<meta property="og:title" content="GharPayy — Best PG in Bangalore | Zero Brokerage | Hotel-Like PG">
<meta property="og:description" content="Bangalore's #1 zero-brokerage premium PG. Hotel-like rooms from ₹7,000/month across 30+ areas. #Hotel_kinda_PG">
<meta property="og:image" content="https://gharpayy.com/img/logo/gharpayy_logo2.png">
<meta property="og:url" content="https://gharpayy.com/">
<meta property="og:type" content="website">
<meta property="og:site_name" content="GharPayy">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="GharPayy — Best PG in Bangalore">
<meta name="twitter:description" content="Zero brokerage hotel-like PG across 30+ Bangalore areas. From ₹7,000/month.">
<meta name="twitter:image" content="https://gharpayy.com/img/logo/gharpayy_logo2.png">
<link rel="stylesheet" href="shared.css">
<script type="application/ld+json">
{{
  "@context":"https://schema.org",
  "@graph":[
    {{
      "@type":"Organization",
      "name":"GharPayy",
      "url":"https://gharpayy.com",
      "logo":"{LOGO}",
      "contactPoint":{{"@type":"ContactPoint","telephone":"{PHONE}","contactType":"customer service","areaServed":"Bangalore"}},
      "sameAs":["https://www.youtube.com/@gharpayy"],
      "creator":{{"@type":"SoftwareApplication","name":"Perplexity Computer","url":"https://www.perplexity.ai/computer"}}
    }},
    {{
      "@type":"WebSite",
      "name":"GharPayy",
      "url":"https://gharpayy.com",
      "description":"Bangalore's premium zero-brokerage PG and co-living brand"
    }},
    {{
      "@type":"FAQPage",
      "mainEntity":{faq_schema}
    }}
  ]
}}
</script>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar" role="navigation" aria-label="Main Navigation">
  <div class="container">
    <a class="navbar-logo" href="index.html" aria-label="GharPayy Home">
      <img src="{LOGO}" alt="GharPayy Logo" width="140" height="38">
    </a>
    <div class="navbar-cta">
      <a class="btn btn-outline btn-sm" href="{WHATSAPP}" target="_blank" rel="noopener">💬 Talk Now</a>
      <a class="btn btn-gold btn-sm" href="{BOOKING}" target="_blank" rel="noopener">📅 Stay Here</a>
    </div>
  </div>
</nav>

<!-- HERO -->
<section class="hero" style="padding:6rem 0 5rem;" aria-labelledby="index-h1">
  <div class="container">
    <div class="hero-inner" style="max-width:820px;">
      <div class="hero-badge">🏨 Bangalore's #1 Zero Brokerage PG Brand</div>
      <h1 id="index-h1">GharPayy — Where PG Stands for <span class="highlight">Personal Growth</span></h1>
      <p class="hero-sub">Hotel-like furnished rooms across 30+ Bangalore areas near top IT companies, colleges &amp; tech parks. Zero brokerage. Rooms from ₹7,000/month.</p>
      <div class="hero-chips">
        <span class="chip gold">📍 30+ Bangalore Areas</span>
        <span class="chip gold">💰 ₹7k – ₹45k / month</span>
        <span class="chip green">⭐ 4.8★ Rating</span>
        <span class="chip green">✅ Zero Brokerage Always</span>
        <span class="chip">🏨 #Hotel_kinda_PG</span>
      </div>
      <div class="cta-group">
        <a class="btn btn-gold btn-lg" href="{WHATSAPP}" target="_blank" rel="noopener">💬 Talk Now</a>
        <a class="btn btn-outline btn-lg" href="{BOOKING}" target="_blank" rel="noopener">📅 Stay Here</a>
        <a class="btn btn-ghost btn-lg" href="{TEL}">📞 Call Now</a>
      </div>
    </div>
  </div>
</section>

<!-- STATS STRIP -->
<div class="stats-strip">
  <div class="container">
    <div class="stats-grid">
      <div class="stat-item"><div class="value">500+</div><div class="label">Happy Residents</div></div>
      <div class="stat-item"><div class="value">30+</div><div class="label">Areas Covered</div></div>
      <div class="stat-item"><div class="value">₹0</div><div class="label">Brokerage</div></div>
      <div class="stat-item"><div class="value">4.8★</div><div class="label">Avg Rating</div></div>
      <div class="stat-item"><div class="value">120+</div><div class="label">SEO Pages</div></div>
      <div class="stat-item"><div class="value">24/7</div><div class="label">Support</div></div>
    </div>
  </div>
</div>

<!-- AREA PAGES -->
<section class="section" aria-labelledby="area-h2">
  <div class="container">
    <div class="section-header">
      <span class="eyebrow">📍 Area Pages</span>
      <h2 id="area-h2">PG in Bangalore by Area</h2>
      <div class="gold-line"></div>
      <p>Find zero-brokerage PG accommodation in every major Bangalore neighbourhood.</p>
    </div>
    <div class="explore-grid">
      {chr(10).join([f'<a class="explore-link" href="{f}">{t}</a>' for f,t in area_pages])}
    </div>
  </div>
</section>

<!-- COLLEGE PAGES -->
<section class="section content-section" aria-labelledby="college-h2">
  <div class="container">
    <div class="section-header">
      <span class="eyebrow">🎓 Near Colleges</span>
      <h2 id="college-h2">PG near Bangalore Colleges &amp; Universities</h2>
      <div class="gold-line"></div>
      <p>Student PG near top Bangalore colleges — safe, furnished, WiFi, food, zero brokerage.</p>
    </div>
    <div class="explore-grid">
      {chr(10).join([f'<a class="explore-link" href="{f}">{t}</a>' for f,t in college_pages])}
    </div>
  </div>
</section>

<!-- TECH PARK / COMPANY PAGES -->
<section class="section" aria-labelledby="company-h2">
  <div class="container">
    <div class="section-header">
      <span class="eyebrow">🏢 Near Tech Parks</span>
      <h2 id="company-h2">PG near IT Companies &amp; Tech Parks</h2>
      <div class="gold-line"></div>
      <p>Minimal commute PG for professionals at Wipro, Infosys, Google, Flipkart and 25+ more companies.</p>
    </div>
    <div class="explore-grid">
      {chr(10).join([f'<a class="explore-link" href="{f}">{t}</a>' for f,t in company_pages])}
    </div>
  </div>
</section>

<!-- RENTAL PAGES -->
<section class="section content-section" aria-labelledby="rental-h2">
  <div class="container">
    <div class="section-header">
      <span class="eyebrow">🏠 Flat Rentals</span>
      <h2 id="rental-h2">1BHK &amp; 2BHK Rentals in Bangalore</h2>
      <div class="gold-line"></div>
      <p>Fully furnished zero-brokerage flat rentals across Bangalore's most sought-after neighbourhoods.</p>
    </div>
    <div class="explore-grid">
      {chr(10).join([f'<a class="explore-link" href="{f}">{t}</a>' for f,t in rental_pages])}
    </div>
  </div>
</section>

<!-- SPECIAL PAGES -->
<section class="section" aria-labelledby="special-h2">
  <div class="container">
    <div class="section-header">
      <span class="eyebrow">✨ Special Searches</span>
      <h2 id="special-h2">Co-living, Girls PG, Boys PG &amp; More</h2>
      <div class="gold-line"></div>
      <p>Targeted PG search pages for co-living, girls-only, boys-only, luxury, affordable, furnished, food &amp; WiFi.</p>
    </div>
    <div class="explore-grid">
      {chr(10).join([f'<a class="explore-link" href="{f}">{t}</a>' for f,t in special_pages])}
    </div>
  </div>
</section>

<!-- PRICING -->
<section class="section content-section" aria-labelledby="pricing-idx-h2">
  <div class="container">
    <div class="section-header text-center">
      <span class="eyebrow">💰 Pricing Tiers</span>
      <h2 id="pricing-idx-h2">GharPayy Pricing — 4 Tiers for Every Budget</h2>
      <div class="gold-line center"></div>
      <p>Zero brokerage on all tiers. All prices include WiFi, power backup, and housekeeping.</p>
    </div>
    <div class="pricing-grid">
      <div class="price-card">
        <div class="tier-name">BASIC</div>
        <div class="tier-price">₹7k–₹11k <span>/month</span></div>
        <div class="tier-desc">Shared rooms, all essentials</div>
        <ul class="tier-features">
          <li>Shared room (2–3 occupants)</li><li>High-speed WiFi</li><li>Fan / non-AC</li><li>Common bathroom</li><li>Weekly housekeeping</li>
        </ul>
      </div>
      <div class="price-card featured">
        <div class="badge-popular">MOST POPULAR</div>
        <div class="tier-name">CLASSICS</div>
        <div class="tier-price">₹12k–₹17k <span>/month</span></div>
        <div class="tier-desc">Semi-private, AC, daily clean</div>
        <ul class="tier-features">
          <li>Double / semi-private room</li><li>AC included</li><li>WiFi + daily housekeeping</li><li>Attached or shared bath</li><li>Food options available</li>
        </ul>
      </div>
      <div class="price-card">
        <div class="tier-name">PRIVE</div>
        <div class="tier-price">₹17k–₹26k <span>/month</span></div>
        <div class="tier-desc">Private room, premium feel</div>
        <ul class="tier-features">
          <li>Private single room</li><li>AC + premium mattress</li><li>Attached bathroom</li><li>Smart TV (select)</li><li>Gym access (select)</li>
        </ul>
      </div>
      <div class="price-card">
        <div class="tier-name">LUXE MAX</div>
        <div class="tier-price">₹25k–₹45k <span>/month</span></div>
        <div class="tier-desc">Hotel-level luxury suite</div>
        <ul class="tier-features">
          <li>Luxury private suite</li><li>Premium AC + mattress</li><li>En-suite bathroom</li><li>Smart TV + work desk</li><li>Full amenities access</li>
        </ul>
      </div>
    </div>
    <p style="text-align:center; margin-top:1.5rem;"><span class="zero-brokerage-badge">✅ Zero Brokerage on ALL Tiers — Always</span></p>
  </div>
</section>

<!-- ABOUT SECTION -->
<section class="section" aria-labelledby="about-h2">
  <div class="container">
    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:3rem; align-items:start;" class="grid-2">
      <div class="prose">
        <h2 id="about-h2">Why GharPayy is Bangalore's Best PG Brand</h2>
        <div class="gold-line"></div>
        <p>GharPayy was built with one conviction: <em>where you live shapes who you become</em>. We obsess over every detail of your living experience — the mattress you sleep on, the speed of your WiFi, the quality of your food, and the people you share your home with.</p>
        <p>Unlike traditional PGs run by individual landlords, GharPayy is a professionally managed co-living brand. Our properties are regularly maintained, professionally staffed, and designed to create a positive, growth-oriented community atmosphere.</p>
        <h3>Our Promise</h3>
        <ul>
          <li>Zero brokerage — always, everywhere, for every plan</li>
          <li>Hotel-like rooms that feel like home</li>
          <li>Transparent, all-inclusive pricing</li>
          <li>A community of professionals who uplift each other</li>
          <li>24/7 support that actually responds</li>
        </ul>
        <p><strong>GharPayy — Where PG Stands for Personal Growth. #Hotel_kinda_PG</strong></p>
      </div>
      <div class="prose">
        <h2>Dominating Bangalore's PG Market</h2>
        <div class="gold-line"></div>
        <p>GharPayy operates across <strong>30+ areas</strong> in Bangalore, with properties near all major tech corridors — Electronic City, Whitefield, Marathahalli ORR, Sarjapur Road, Manyata Tech Park, Hebbal, and more.</p>
        <p>Our coverage includes PG near <strong>25+ leading IT companies</strong> (Infosys, Wipro, TCS, Accenture, Microsoft, Google, Amazon, Flipkart, Swiggy, PhonePe, Razorpay and more), <strong>25+ colleges and universities</strong>, and properties tailored for girls PG, boys PG, co-living, luxury stays, and affordable budgets.</p>
        <h3>GharPayy by Numbers</h3>
        <ul>
          <li>500+ happy residents and growing</li>
          <li>4.8-star average resident rating</li>
          <li>30+ neighbourhood pages on our site</li>
          <li>120+ SEO pages covering all Bangalore PG searches</li>
          <li>₹0 brokerage charged — ever</li>
          <li>24-hour move-in from booking</li>
        </ul>
      </div>
    </div>
  </div>
</section>

<!-- YOUTUBE SECTION -->
<section class="section content-section" aria-labelledby="yt-h2">
  <div class="container">
    <div class="yt-section">
      <div class="yt-badge">▶ YouTube</div>
      <h2 id="yt-h2">GharPayy on YouTube — Virtual Room Tours</h2>
      <div class="gold-line"></div>
      <p>Before you book, explore GharPayy properties through our virtual room tours on YouTube. Search <strong>"GharPayy Bangalore PG"</strong> on YouTube or visit our channel directly.</p>
      <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(240px,1fr)); gap:1rem; margin:1.5rem 0;">
        <div class="card">
          <div class="card-icon">🎬</div>
          <h4>Room Tour Videos</h4>
          <p style="font-size:0.85rem;">Virtual walkthroughs of all 4 pricing tiers — BASIC, CLASSICS, PRIVE, and LUXE MAX.</p>
        </div>
        <div class="card">
          <div class="card-icon">🏘️</div>
          <h4>Co-living Community Tours</h4>
          <p style="font-size:0.85rem;">See the common areas, dining spaces, and the GharPayy community in action.</p>
        </div>
        <div class="card">
          <div class="card-icon">📍</div>
          <h4>Location Walkthroughs</h4>
          <p style="font-size:0.85rem;">Neighbourhood tours showing proximity to tech parks, metro stations, and landmarks.</p>
        </div>
        <div class="card">
          <div class="card-icon">🗣️</div>
          <h4>Resident Testimonials</h4>
          <p style="font-size:0.85rem;">Real stories from GharPayy residents — their experience, community, and Personal Growth.</p>
        </div>
      </div>
      <div style="margin-top:1rem;">
        <a class="btn btn-outline" href="https://www.youtube.com/@gharpayy" target="_blank" rel="noopener">▶ Visit GharPayy YouTube Channel</a>
      </div>
      <p style="margin-top:1rem; font-size:0.82rem; color:var(--muted);">Search keywords: <em>gharpayy youtube · best pg bangalore youtube · pg room tour bangalore · co-living bangalore video tour · gharpayy bangalore pg</em></p>
    </div>
  </div>
</section>

<!-- FAQ -->
<section class="section" aria-labelledby="faq-idx-h2">
  <div class="container">
    <div class="section-header">
      <span class="eyebrow">❓ Frequently Asked</span>
      <h2 id="faq-idx-h2">GharPayy — Common Questions</h2>
      <div class="gold-line"></div>
    </div>
    <div class="faq-list">
      <div class="faq-item"><div class="faq-q">What is GharPayy?<span class="arrow">▼</span></div><div class="faq-a">GharPayy is Bangalore's premium zero-brokerage PG and co-living brand offering hotel-like managed accommodation for working professionals and students. We operate across 30+ areas in Bangalore with four pricing tiers from ₹7,000 to ₹45,000/month.</div></div>
      <div class="faq-item"><div class="faq-q">Does GharPayy charge brokerage?<span class="arrow">▼</span></div><div class="faq-a">No. GharPayy is a 100% zero-brokerage PG brand. You never pay brokerage fees when booking through us — anywhere in Bangalore, for any tier.</div></div>
      <div class="faq-item"><div class="faq-q">What is the cheapest PG at GharPayy?<span class="arrow">▼</span></div><div class="faq-a">GharPayy's BASIC tier starts at ₹7,000/month for shared rooms with essential amenities including high-speed WiFi and power backup.</div></div>
      <div class="faq-item"><div class="faq-q">Does GharPayy provide food?<span class="arrow">▼</span></div><div class="faq-a">Yes, food options are available at GharPayy properties. Freshly prepared breakfast and dinner are available as add-ons or bundled in select CLASSICS and higher tier plans.</div></div>
      <div class="faq-item"><div class="faq-q">How do I book a GharPayy PG?<span class="arrow">▼</span></div><div class="faq-a">Book via WhatsApp at +918307396042, schedule a site visit at cal.com/gharpayy.com/stay, or call us directly. Our team responds within minutes.</div></div>
    </div>
  </div>
</section>

<!-- CTA STRIP -->
<section class="cta-strip" aria-labelledby="cta-idx-h2">
  <div class="container">
    <h2 id="cta-idx-h2">Find Your GharPayy PG in Bangalore Today</h2>
    <p>Join 500+ residents living the hotel-kinda PG life. Zero brokerage, premium rooms, vibrant community.</p>
    <div class="cta-group">
      <a class="btn btn-gold btn-lg" href="{WHATSAPP}" target="_blank" rel="noopener">💬 Talk Now — WhatsApp</a>
      <a class="btn btn-outline btn-lg" href="{BOOKING}" target="_blank" rel="noopener">📅 Book a Visit</a>
      <a class="btn btn-ghost btn-lg" href="{TEL}">📞 +91 83073 96042</a>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer class="footer" role="contentinfo">
  <div class="container">
    <div class="footer-grid">
      <div>
        <div class="footer-logo">
          <a href="index.html"><img src="{LOGO}" alt="GharPayy Logo" width="130" height="36"></a>
        </div>
        <p class="footer-tagline">Where PG Stands for Personal Growth<br><strong style="color:var(--gold)">#Hotel_kinda_PG</strong></p>
        <p class="footer-tagline" style="margin-top:0.75rem;">Bangalore's premium zero-brokerage PG &amp; co-living brand. 30+ areas covered.</p>
      </div>
      <div class="footer-col">
        <h4>Top Areas</h4>
        <ul>
          <li><a href="pg-in-sarjapur.html">PG in Sarjapur</a></li>
          <li><a href="pg-in-brookefield.html">PG in Brookefield</a></li>
          <li><a href="pg-in-mahadevapura.html">PG in Mahadevapura</a></li>
          <li><a href="pg-in-horamavu.html">PG in Horamavu</a></li>
          <li><a href="pg-in-hennur.html">PG in Hennur</a></li>
          <li><a href="pg-in-kengeri.html">PG in Kengeri</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Near Companies</h4>
        <ul>
          <li><a href="pg-near-wipro-campus-sarjapur.html">Near Wipro</a></li>
          <li><a href="pg-near-infosys-electronic-city.html">Near Infosys</a></li>
          <li><a href="pg-near-google-bangalore.html">Near Google</a></li>
          <li><a href="pg-near-microsoft-bangalore.html">Near Microsoft</a></li>
          <li><a href="pg-near-flipkart-bangalore.html">Near Flipkart</a></li>
          <li><a href="pg-near-amazon-bangalore.html">Near Amazon</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Contact &amp; Links</h4>
        <ul>
          <li><a href="{WHATSAPP}" target="_blank" rel="noopener">💬 WhatsApp Us</a></li>
          <li><a href="{TEL}">📞 +91 83073 96042</a></li>
          <li><a href="{BOOKING}" target="_blank" rel="noopener">📅 Book a Visit</a></li>
          <li><a href="https://www.youtube.com/@gharpayy" target="_blank" rel="noopener">▶ YouTube</a></li>
          <li><a href="sitemap.xml">🗺️ Sitemap</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© 2025 GharPayy. All rights reserved. Zero Brokerage Always.</span>
      <a href="https://www.perplexity.ai/computer" target="_blank" rel="noopener noreferrer" style="color:var(--muted);">Created with Perplexity Computer</a>
    </div>
  </div>
</footer>

<script>
document.querySelectorAll('.faq-q').forEach(function(q) {{
  q.addEventListener('click', function() {{
    var item = q.closest('.faq-item');
    item.classList.toggle('open');
  }});
}});
</script>
</body>
</html>"""
    return html

# ─────────────── Sitemap builder ────────────────────────────────────────────
def build_sitemap():
    urls = [("", "1.0", "daily")]
    for p in PAGES:
        urls.append((p[0], "0.8", "weekly"))
    lines = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for path, pri, freq in urls:
        url = f"https://gharpayy.com/{path}" if path else "https://gharpayy.com/"
        lines.append(f"  <url><loc>{url}</loc><changefreq>{freq}</changefreq><priority>{pri}</priority></url>")
    lines.append("</urlset>")
    return "\n".join(lines)

# ─────────────── Main runner ─────────────────────────────────────────────────
def main():
    OUT.mkdir(parents=True, exist_ok=True)
    count = 0
    errors = []

    print(f"Building {len(PAGES)} pages...")
    for page_data in PAGES:
        filename, title, h1_text, meta_desc, page_type, area, extra = page_data
        try:
            html = build_page(filename, title, h1_text, meta_desc, page_type, area, extra)
            (OUT / filename).write_text(html, encoding="utf-8")
            count += 1
            if count % 10 == 0:
                print(f"  Built {count} pages...")
        except Exception as e:
            errors.append((filename, str(e)))
            print(f"  ERROR on {filename}: {e}")

    # Build index
    try:
        (OUT / "index.html").write_text(build_index(), encoding="utf-8")
        count += 1
        print("  Built index.html")
    except Exception as e:
        errors.append(("index.html", str(e)))

    # Build sitemap
    try:
        (OUT / "sitemap.xml").write_text(build_sitemap(), encoding="utf-8")
        print("  Built sitemap.xml")
    except Exception as e:
        errors.append(("sitemap.xml", str(e)))

    print(f"\nDone! Built {count} HTML files + sitemap.xml")
    if errors:
        print(f"Errors ({len(errors)}):")
        for f, e in errors:
            print(f"  {f}: {e}")
    return count, errors

if __name__ == "__main__":
    main()
